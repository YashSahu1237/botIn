package in.yesmadam.botin.api.dto;

import java.util.UUID;

/**
 * The whole client-visible state of a help session. Returned by every session
 * endpoint, so reconnecting and acting return the same shape — a client that can
 * render a response can render a reconnect, with no second code path.
 */
public record SessionView(
        UUID sessionId,
        String spId,
        String status,
        String currentStep,
        String l1Concern,
        String l2Concern,
        NextStep nextStep) { }
