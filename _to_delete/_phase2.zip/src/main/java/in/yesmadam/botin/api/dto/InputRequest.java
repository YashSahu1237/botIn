package in.yesmadam.botin.api.dto;

/**
 * One turn from the partner. Exactly one of these is expected to be set, matching
 * the StepType that was last returned.
 *
 * @param selection the {@code code} of the chosen Option, for MENU and DROPDOWN
 * @param freeText  typed text, for TEXT
 */
public record InputRequest(String selection, String freeText) { }
