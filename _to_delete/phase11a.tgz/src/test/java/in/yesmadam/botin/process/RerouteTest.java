package in.yesmadam.botin.process;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.yesmadam.botin.session.TicketRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * PLAN STEP 86 — the partner typed the wrong thing into the wrong place, end to end.
 *
 * THE ASSERTION THAT MATTERS is that a rerouted session is INDISTINGUISHABLE from one
 * that arrived through the menu: same session row, same concern recorded, same nextStep,
 * same Gate 1 behaviour. If a reroute produced a slightly different shape, every report
 * and every downstream phase would have two cases to handle forever.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class RerouteTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired TicketRepository tickets;

    @Test
    @DisplayName("Free text naming another concern reroutes into it, and it resolves there")
    void aConfidentMatchReroutesAndResolves() throws Exception {
        // The partner opened Help by typing, then picked their way to the triage concern.
        String sessionId = start("SP-RR-01", "mera mpin bhool gaya");
        send(sessionId, "OTHER_ISSUES");
        JsonNode view = send(sessionId, "OTHER_FREETEXT_TRIAGE");

        // They asked about their MPIN, so they get the MPIN answer — not a ticket about
        // having typed something into a triage flow.
        assertEquals("FORGET_MPIN_DEFLECT", view.at("/nextStep/code").asText(),
                "the partner should get an answer about the thing they actually asked about");
        assertEquals("FORGET_MPIN", view.get("l2Concern").asText(),
                "the session moves to the real concern — otherwise every report attributes "
              + "this case to the triage flow it passed through");
        assertEquals("CLOSED_DEFLECTED", view.get("status").asText());

        // AND IT IS STILL A T0. Rerouting into a deflection must not file anything; if it
        // did, every rerouted partner would quietly become a ticket.
        assertEquals(0, tickets.countBySpId("SP-RR-01"),
                "a reroute into a T0 crosses Gate 1 exactly as often as a T0 does: never");
    }

    @Test
    @DisplayName("A rerouted session is indistinguishable from one that came through the menu")
    void theReroutedSessionLooksLikeAnyOther() throws Exception {
        String rerouted = start("SP-RR-02", "mpin bhool gaya");
        send(rerouted, "OTHER_ISSUES");
        JsonNode viaText = send(rerouted, "OTHER_FREETEXT_TRIAGE");

        String direct = start("SP-RR-03", null);
        send(direct, "AMOUNT_RELATED");
        JsonNode viaMenu = send(direct, "FORGET_MPIN");

        assertEquals(viaMenu.at("/nextStep").toString(), viaText.at("/nextStep").toString(),
                "two routes, one answer — nothing downstream should be able to tell them apart");
        assertEquals(viaMenu.get("status").asText(), viaText.get("status").asText());
        assertEquals(viaMenu.get("l2Concern").asText(), viaText.get("l2Concern").asText());
    }

    @Test
    @DisplayName("Text the classifier cannot place reaches a human, with the transcript")
    void unrecognisedTextGoesToAPerson() throws Exception {
        String sessionId = start("SP-RR-04", "bhai kal wala kaam ka kya hua");
        send(sessionId, "OTHER_ISSUES");
        JsonNode view = send(sessionId, "OTHER_FREETEXT_TRIAGE");

        assertEquals("AGENT_CONNECTING", view.at("/nextStep/code").asText());
        assertEquals("OTHER_FREETEXT_TRIAGE", view.get("l2Concern").asText(),
                "no reroute happened, so the concern must not have moved");
        assertEquals(1, tickets.countBySpId("SP-RR-04"), "an unplaceable case is a real ticket");
    }

    @Test
    @DisplayName("A risk word reaches a person even though the text names a concern")
    void riskFlaggedTextIsNeverRerouted() throws Exception {
        // This is the one that matters most. Without trigger E sitting above the match
        // row, a partner describing an accident would be handed a self-serve deeplink by
        // a model that was 95% sure it knew what they meant.
        String sessionId = start("SP-RR-05", "accident ho gaya aur mpin bhi bhool gaya");
        send(sessionId, "OTHER_ISSUES");
        JsonNode view = send(sessionId, "OTHER_FREETEXT_TRIAGE");

        assertEquals("AGENT_CONNECTING", view.at("/nextStep/code").asText());
        assertNotEquals("FORGET_MPIN", view.get("l2Concern").asText(),
                "a risk-flagged message must never be self-served, however confident the match");
    }

    @Test
    @DisplayName("The reroute is recorded on the ticket when one is opened")
    void theTriageTicketNamesWhatHappened() throws Exception {
        String sessionId = start("SP-RR-06", "kuch samajh nahi aa raha");
        send(sessionId, "OTHER_ISSUES");
        send(sessionId, "OTHER_FREETEXT_TRIAGE");

        var ticket = tickets.findTop10BySpIdOrderByCreatedAtDesc("SP-RR-06").get(0);
        assertEquals("T3", ticket.getTier());
        assertEquals("TICKET_WITH_TRANSCRIPT", ticket.getDmnAction(),
                "the agent needs to know this arrived as unplaceable free text");
    }

    // ------------------------------------------------------------------ helpers

    private String start(String spId, String freeText) throws Exception {
        String body = freeText == null
                ? "{\"spId\":\"" + spId + "\"}"
                : "{\"spId\":\"" + spId + "\",\"freeText\":\"" + freeText + "\"}";

        String response = mvc.perform(post("/help/sessions")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(response).get("sessionId").asText();
    }

    private JsonNode send(String sessionId, String selection) throws Exception {
        String body = mvc.perform(post("/help/sessions/" + sessionId + "/input")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"selection\":\"" + selection + "\"}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(body);
    }
}
