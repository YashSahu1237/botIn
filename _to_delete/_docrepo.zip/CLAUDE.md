# CLAUDE.md — BOTIn Mod

**Read this file first.** It is the continuity record for this project. If a session is
lost, everything needed to resume is here or linked from here. Keep it current: when
something is decided, discovered, or finished, it gets written down here, not left in a
chat transcript.

---

## 1. What this project is

**BOTIn Mod** is a bot-first, tiered outbound support system for Service Partners (SPs).
An SP taps Help, picks an L1 concern, then an L2 sub-concern, and the system resolves it
without a human wherever it safely can.

**The tier model — the single most important idea in the system:**

| Tier | Meaning | Ticket created? |
|------|---------|-----------------|
| T0 | Deflect — answer and stop | **No** |
| T1 | Auto-resolve — an answer the bot owns | Yes |
| T2 | Auto-action — moves money or changes state | Yes |
| T3 | Agent connect — a human takes it | Yes |

**Gate 1** is the moment a ticket row is created. A T0 deflection must never cross it.
Proving that — zero rows in `ticket` after a successful T0 — is an explicit POC goal, not
an implementation detail.

**Agent connect is over chat.** Not voice. The design documents say so explicitly and
note that this needs revisiting if the business later wants voice.

---

## 2. STANDING RULES — do not violate these

These came from the project owner directly. They are not preferences.

1. **No timelines, effort estimates, author names, versions or dates in any BOTIn
   document.** Documents describe the module, not the project management around it. This
   applies to every HTML/doc deliverable. (This file is an internal working record and is
   the one exception, and even here: no effort estimates, no names.)

2. **Nothing BOTIn creates may be written to the UAT database, ever.** UAT is a *second*
   datasource, read-only, `SELECT`-only by GRANT. No JPA, no Flyway, no Flowable on it.
   See §5 for how this is enforced in code.

3. **Use exact production table and column names when reading UAT**, so the SQL does not
   have to change when it points at production later.

4. **No production money moves in the POC.** Every money-adjacent action writes to a mock.

5. **Published artifacts contain internal detail** (`empapi`, `admin`, `app_server`, SP
   fine/wallet/strike rules, medal bands, ticket volumes). They are private by default.
   Do not make one public without being asked.

6. **Explain from the problem first.** When explaining anything: start with the real
   situation, then what the dependency literally is, then the concepts, then the advanced
   behaviour. Leading with mechanics has failed here before.

---

## 3. Where everything is

Everything lives under this project root. Nothing is stored only in a chat.

```
botin/
├── CLAUDE.md                  <- this file
├── pom.xml
├── src/                       <- the POC service (see §5)
└── docs/
    ├── README.md              <- index of the repository
    ├── design/
    │   ├── 01-decision-brief.html       Part A — the decision-level document
    │   ├── 02-engineering-design.html   Part B — the engineering document (AUTHORITATIVE)
    │   └── 03-decision-engine.html      all 113 decision rules across 38 concerns
    ├── planning/
    │   ├── poc-build-plan.html          the 98-step build plan
    │   ├── poc-tracker.xlsx             live status — Summary / Next up / Steps / Evidence
    │   └── component-notes.html         what each dependency is and why it was chosen
    ├── data/
    │   ├── concern_catalogue.csv        38 concerns
    │   ├── decision_rules.csv           113 rules
    │   ├── decision_facts.csv           9 fact domains, 67 signals
    │   ├── shared_services.csv          10 shared services
    │   └── caps_and_thresholds.csv      18 caps
    ├── spikes/                          the R&D ladder, all green (see §6)
    └── superseded/                      STALE. Kept for history. Do not build from these.
```

**`poc-tracker.xlsx` is the source of truth for status.** The Summary tab is formula-driven
off the Steps tab — change a Status cell and the rest recalculates.

---

## 4. Current state

**R&D ladder: complete, 6 of 6 green.**

**Phase 1 (plan steps 23–31): DONE.** `mvn test` passes 6/6 on the project owner's machine.

**Next: Phase 2 (plan steps 32–37)** — the catalogue API and the L1 → L2 → `nextStep`
chain. This is the first thing that behaves like a chat bot from outside. It needs nothing
from anyone else to start.

**Then Phase 3 (steps 38–40)** — `FORGET_MPIN` end to end as a T0, asserting **zero** rows
in `ticket`.

### Blocked on the project owner

- **Real UAT table and column names.** Every query in `TransportFactProvider` is a
  `TODO(schema)` placeholder with a guessed table name (`sp_wallet_txn`, `booking_charge`,
  `booking_event`, `booking`). Until these arrive, that provider returns nothing useful.
- **Confirmation the UAT user is `SELECT`-only by GRANT.** The code cannot write; a GRANT
  means nothing can.

### Blocked on procurement

- **The LLM track (plan steps 10–11, 15–22).** No API key, no model decision. Steps 7–9
  (task spec, NFRs, PII position) need nobody and can be done at any time.

### Unresolved, raised more than once, never answered

- **D-1, hosting.** The Decision Brief still lists hosting as an open decision while the
  Engineering Design states `empapi` as settled. One of the two is wrong. Ask.

---

## 5. The service — what exists and why

Spring Boot 3.2.5, Java 17, Postgres in production, H2 for tests.

```
in.yesmadam.botin
├── BotinApplication.java
├── config/     datasource wiring — the UAT isolation lives here
├── session/    HelpSession, Ticket + repositories
├── catalogue/  ConcernCatalogue + repository — the L1/L2 taxonomy
├── facts/      how a concern fetches the data it needs to decide
└── safety/     the two guards
```

Packages `api/`, `process/`, `decision/`, `action/` and `agent/` are named in the plan and
arrive in later phases. They do not exist yet.

### UAT isolation — four structural protections

Hibernate creates tables. Flyway creates tables. Flowable creates about 25 of its own. All
of them do it by default, against whatever datasource they find. So the isolation is not a
setting — it is four facts, all in `config/`:

1. The UAT datasource is **not `@Primary`** — nothing auto-wires to it by accident.
2. It has **no `EntityManagerFactory`** — no JPA at all, so `ddl-auto` cannot see it.
3. **Flyway is bound to the primary datasource** explicitly.
4. **`FlowableConfig` hands Flowable the primary `DataSource` by name**, rather than
   letting the engine choose one.

What is exposed from UAT is a single `JdbcTemplate`, `setReadOnly(true)`, 5-second query
timeout. `ConditionalOnUatEnabled` switches the whole thing off, which is why `mvn test`
needs no UAT connection.

### The database — 7 tables

`concern_catalogue`, `help_session`, `ticket`, `ticket_action`, `conversation_message`,
`escalation_context`, `sp_counter`.

- **`concern_catalogue`** is the taxonomy, and four of its columns are *pointers*:
  `process_key` → a BPMN process, `dmn_key` → a decision table, `fact_provider` → a Java
  bean, `togglz_flag` → a kill switch. **Adding a row does not add a concern.** 38 seeded,
  8 active.
- **`help_session`** is created the instant Help is tapped — *before* any ticket exists.
  That ordering is Gate 1 made concrete.
- **`sp_counter`** was not in the original design. The concern mapping forces it: the
  pooled emergency cap, the monthly period-leave count and the 25-job cycle allowances are
  **state this engine owns**, not facts it can read from anywhere else.

### The two safety guards

**`TicketActionRecorder`** — `@Transactional(propagation = REQUIRES_NEW)`. This is ADR-005
and it is the money-safety mechanism. An attempt row written inside it **survives the
caller's transaction rolling back**, so a retry cannot pay twice with no record of the
first attempt. It is the only place allowed to write a money-adjacent attempt row, so
there is one thing to audit rather than many. The rollback test is in the suite
specifically to fail if someone deletes the annotation.

**`FeatureNameValidator`** — runs on `ApplicationReadyEvent` and refuses to boot if any
`concern_catalogue.togglz_flag` is not a declared `BotinFeature`. It exists because a spike
proved Togglz resolves an unknown flag name to `false` **silently — no exception, no log
line**. With fail-to-human semantics, one typo routes an entire concern to agents and
nothing anywhere reports it.

### Tests — 6, and what each is for

`SchemaAndCatalogueTest` (3): all seven of our tables exist after Flyway · more than 15
`ACT_*` tables exist, proving our schema and Flowable's coexist in one database · the
catalogue returns only active concerns.

`TicketActionRecorderTest` (3): **the attempt row survives caller rollback** · a second
attempt with the same idempotency key short-circuits · the outcome write lands.

---

## 6. The R&D ladder — what was proven

| # | Spike | Result |
|---|-------|--------|
| 1 | Flowable pause / JVM death / resume | PASSED — ADR-001 holds |
| 2 | DMN hit policy and row order | PASSED — row order **is** logic; no catch-all returns `null` |
| 3 | `REQUIRES_NEW` through rollback | PASSED **both** directions |
| 4 | Togglz / Resilience4j / Flyway | 16/16 — and found the Togglz hole |
| 5 | FastAPI + Pydantic classifier contract | 12/12 |
| 6 | Component notes write-up | Delivered |

Spike numbering follows the R&D ladder steps, not the order they were delivered.

---

## 7. Landmines — things that cost time once and must not cost it twice

- **Togglz resolves an unknown flag name to `false` silently.** No error anywhere. This is
  why `FeatureNameValidator` exists and why it is mandatory, not advisory.
- **`ACT_RU_*` rows are deleted when a process instance completes.** `nextStep` must
  therefore be written to `help_session` by the final Service Task, never read back from
  process variables.
- **Spring self-invocation silently disables `@Transactional`.** Calling an annotated
  method from another method of the same bean bypasses the proxy. The annotation appears
  to be there and does nothing.
- **DMN `FIRST` hit policy means row order is logic.** A table with no catch-all row
  returns `null`, not a default.
- **H2 cannot run `MODE=PostgreSQL` in this project.** Flowable detects H2 and emits H2
  DDL containing the `IDENTITY` type, which H2 rejects while in PostgreSQL mode. The core
  schema is therefore written in types both engines accept natively — no `TIMESTAMPTZ`
  (use `TIMESTAMP WITH TIME ZONE`), no `TEXT` (use `VARCHAR(n)`; `TEXT` is an alias for
  `CLOB` in native H2 and Hibernate's `validate` rejects it for a `String` field).
- **`flyway-database-postgresql` is a Flyway 10 module.** Spring Boot 3.2.x manages Flyway
  9.x, where Postgres support is inside `flyway-core`. Declaring it breaks the build with a
  missing-version error.
- **Maven Central is blocked from the Claude cloud container** (403 at the egress proxy).
  Java cannot be compiled there. Builds happen on the project owner's machine. The Linux
  shell Claude gets on that machine is a *separate sandboxed VM*, not the Mac — it has no
  Maven and cannot see the real `~/.m2`.

---

## 8. Known assumptions and compromises

- **`derivePath()` in `TransportFactProvider` is an assumption.** Transport rules 2–8 are
  labelled Path 1/2/3 but nothing in the concern mapping says what assigns a claim to a
  path. It is derived from `customerCharged` / `alreadyCredited` / `cancellationStatus` in
  one named method, deliberately in one place, so the real rule is a single edit.
- **`VARCHAR(4000)` caps.** Eleven columns that should be `TEXT` in Postgres are capped so
  the same DDL runs on H2. `facts_snapshot` and `request_payload` are the two where 4000 is
  a real ceiling. The clean fix is testing against real Postgres via Testcontainers, which
  adds a Docker dependency and was deferred to Phase 4.

---

## 9. Findings from the concern mapping that change scope

- **Fine Related is DEPRECATED** — 12,781 volume. The POC's original subject no longer
  exists.
- **13,823 tickets (37%) leave the build** once DEPRECATED and REROUTE are removed.
- **Violations has no volume figure at all** — 17 of 38 concerns, 54 of 113 rules.
- **Only 6 of 113 rules move money.** The money-safety machinery guards a small, findable
  surface.
- **14 rules are REROUTE**, an outcome type with no equivalent anywhere in the design.
- **13 concerns have no catch-all rule.** With DMN `FIRST`, they return `null`.
- **12 rules are not machine-evaluable** — "substantial emergency" appears five times.

---

## 10. Build and run

```bash
cd "/Users/admin/Documents/BOTIn Mod/Claude outputs/botin-phase1/botin"

mvn test                  # H2, no database or UAT needed. Should be 6/6.

createdb botin
export BOTIN_DB_URL=jdbc:postgresql://localhost:5432/botin
export UAT_DB_URL=... UAT_DB_USER=... UAT_DB_PASSWORD=...
mvn spring-boot:run       # or UAT_ENABLED=false to boot without UAT
```

Expect on a clean boot: **7** tables from Flyway, **~25** `ACT_*` from Flowable, **38**
concerns seeded with **8** active.

---

## 11. Working agreement

- Every document produced goes into `docs/` in this repository. Nothing lives only in a
  chat.
- Status changes go into `poc-tracker.xlsx`, not into prose.
- Anything learned the hard way goes into §7 of this file.
- When a standing rule in §2 is at risk, stop and say so rather than working around it.
