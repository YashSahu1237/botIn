# BOTIn Mod — document repository

Every document produced for this project. Nothing is stored only in a chat transcript.

Start with **`../CLAUDE.md`** — it is the continuity record and explains the current state,
the standing rules, and what is blocked on whom.

The HTML documents open in any browser. Double-click them.

---

## design/ — the documents that describe the system

| File | What it is |
|------|-----------|
| `01-decision-brief.html` | **Part A.** The decision-level document — what is being built and why, for a reader who will not read code. |
| `02-engineering-design.html` | **Part B.** The engineering document. **This is the authoritative technical description**, including the architecture decision records. |
| `03-decision-engine.html` | All **113 decision rules** across **38 concerns**, with the outcome vocabulary (BOT, TICKET, UPHOLD, REROUTE, SELF-SERVE, V2, DEPRECATED). |

## planning/ — how the build is sequenced and where it stands

| File | What it is |
|------|-----------|
| `poc-tracker.xlsx` | **The source of truth for status.** Four tabs: Summary (formula-driven), Next up, Steps (98 rows), Evidence. Change a Status cell on Steps and Summary recalculates. |
| `poc-build-plan.html` | The 98-step build plan in full, with the reasoning behind the sequencing. |
| `component-notes.html` | What each dependency actually is, why it was chosen, and what the R&D ladder proved about it. Read this before touching Flowable, DMN, Togglz or Resilience4j. |

## data/ — the concern mapping, normalised

Generated from the L1/L2 concern mapping. These are the inputs the decision engine is
built from.

| File | Contents |
|------|----------|
| `concern_catalogue.csv` | 38 concerns |
| `decision_rules.csv` | 113 rules |
| `decision_facts.csv` | 9 fact domains, 67 signals |
| `shared_services.csv` | 10 shared services |
| `caps_and_thresholds.csv` | 18 caps and thresholds |

## spikes/ — the R&D ladder

Throwaway projects, each answering one question that could have invalidated the
architecture. All green. They are kept as evidence, not as code to build on.

| File | Question it answered |
|------|---------------------|
| `spike-1-3-flowable.zip` | Does a Flowable process survive the JVM dying mid-flight? Does `REQUIRES_NEW` survive a caller rollback? |
| `spike-2-dmn.zip` | How does DMN `FIRST` hit policy behave with a deliberately wrong row order, and with no catch-all row? |
| `spike-4-togglz-resilience-flyway.zip` | Do Togglz, Resilience4j and Flyway behave as assumed? **This one found the Togglz silent-false hole.** |
| `spike-4-fix.zip` | The correction to spike 4's own test SQL (H2 quotes Flyway's history table in lower case). |
| `spike-5-classifier.zip` | Does the FastAPI + Pydantic classifier contract hold, including closed enums and bounded confidence? |

## superseded/ — history only

**Do not build from anything in this folder.** These were replaced by the documents in
`design/` and `planning/`. They are kept so a decision can be traced back to where it was
first made.

| File | Replaced by |
|------|------------|
| `tech-design-original.html` | Split into Part A and Part B |
| `combined-tdd.html` | Split into Part A and Part B |
| `layer-reference.html` | Folded into the Engineering Design |
| `flow-map.html` | Folded into the Engineering Design |
| `poc-scope-lock.html` | The 98-step build plan |
| `poc-checklist-56-step.html` | The 98-step build plan |
