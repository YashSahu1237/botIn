package in.yesmadam.botin.process;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.yesmadam.botin.catalogue.CatalogueService;
import in.yesmadam.botin.catalogue.ConcernCatalogue;
import in.yesmadam.botin.decision.Decision;
import in.yesmadam.botin.decision.DecisionService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * STAGE 3 — the concern's own decision table. The only step that decides anything.
 *
 * WHY THE DECISION IS CALLED FROM A DELEGATE AND NOT A BPMN BUSINESS RULE TASK. A
 * businessRuleTask names its decision key in the process file. That would put the same
 * pointer in two places — concern_catalogue.dmn_key and the BPMN — and the two would be
 * free to disagree, which is the one thing ADR-006 exists to prevent. It would also
 * force a BPMN file per concern where one generic file does. The decision is still
 * configuration; only the lookup of WHICH table moved.
 *
 * EVERY PATH OUT OF HERE IS SAFE. The table can return a tier this build cannot act on,
 * the facts can have failed, a rule can match nothing. All three end with a human,
 * which is the only default that cannot hurt a partner.
 */
@Component("decideDelegate")
public class DecideDelegate implements JavaDelegate {

    private static final Logger log = LoggerFactory.getLogger(DecideDelegate.class);

    /** Not one of the five cross-cutting triggers — see EscalationContext.triggerReason. */
    public static final String TRIGGER_CONCERN_DECISION = "CONCERN";

    private final CatalogueService catalogue;
    private final DecisionService decisions;
    private final ObjectMapper json;

    public DecideDelegate(CatalogueService catalogue, DecisionService decisions, ObjectMapper json) {
        this.catalogue = catalogue;
        this.decisions = decisions;
        this.json = json;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String l2Concern = (String) execution.getVariable(ProcessVariables.L2_CONCERN);

        // Trigger B already answered the question. Running the table anyway could only
        // produce a tier we are contractually required to ignore.
        if (Boolean.TRUE.equals(execution.getVariable(ProcessVariables.MANDATORY_HUMAN))) {
            escalate(execution, "AGENT_MANDATORY_HUMAN", PreFlightDelegate.TRIGGER_MANDATORY_HUMAN);
            return;
        }

        if (Boolean.TRUE.equals(execution.getVariable(FetchFactsDelegate.FACTS_FAILED))) {
            escalate(execution, "AGENT_FACTS_UNAVAILABLE", TRIGGER_CONCERN_DECISION);
            return;
        }

        try {
            ConcernCatalogue concern = catalogue.find(l2Concern).orElseThrow();
            Map<String, Object> facts = readFacts(execution);

            Decision decision = decisions.decide(concern.getDmnKey(), facts);

            // ---------------------------------------------------------------------
            // A T2 MOVES MONEY OR CHANGES STATE, AND NOTHING IN THIS BUILD CAN DO
            // EITHER YET. The action services arrive with Phase 6. Until they do, the
            // only honest response to "credit this partner" is to put it in front of a
            // human — telling them their wallet has been credited when nothing has
            // happened is worse than any delay.
            //
            // This is also where the kill-switch gateway belongs once actions exist:
            // flag off means exactly this, do not automate, send to a human. The
            // semantics are already right; the condition is the part that changes.
            // ---------------------------------------------------------------------
            if (decision.movesMoney()) {
                log.warn("{} decided {} (T2) — no action service is built, escalating instead",
                        l2Concern, decision.action());
                escalate(execution, "AGENT_ACTION_NOT_BUILT", TRIGGER_CONCERN_DECISION);
                return;
            }

            // REROUTE needs a target concern and a way to re-enter the flow — Phase 11.
            // Unreachable today because the classifier does not exist, so this is a
            // guard rather than a path, and it must not be a silent one.
            if (decision.isReroute()) {
                log.warn("{} decided REROUTE and rerouting is not built — escalating", l2Concern);
                escalate(execution, "AGENT_REROUTE_NOT_BUILT", TRIGGER_CONCERN_DECISION);
                return;
            }

            execution.setVariable(ProcessVariables.TIER, decision.tier());
            execution.setVariable(ProcessVariables.ACTION, decision.action());
            execution.setVariable(ProcessVariables.OUTCOME_TYPE, decision.outcomeType());

            boolean agentRequired = "T3".equals(decision.tier());
            execution.setVariable(ProcessVariables.AGENT_REQUIRED, agentRequired);
            execution.setVariable(ProcessVariables.TRIGGER_REASON,
                    agentRequired ? TRIGGER_CONCERN_DECISION : null);

            log.info("{} decided tier={} action={} type={}",
                    l2Concern, decision.tier(), decision.action(), decision.outcomeType());

        } catch (Exception e) {
            // A table that matched nothing, a table that failed to evaluate, a dmn_key
            // pointing at nothing. The partner gets a person either way.
            log.error("decision failed for {} — escalating", l2Concern, e);
            escalate(execution, "AGENT_DECISION_FAILED", TRIGGER_CONCERN_DECISION);
        }
    }

    private void escalate(DelegateExecution execution, String action, String triggerReason) {
        execution.setVariable(ProcessVariables.TIER, "T3");
        execution.setVariable(ProcessVariables.ACTION, action);
        execution.setVariable(ProcessVariables.OUTCOME_TYPE, "TICKET");
        execution.setVariable(ProcessVariables.AGENT_REQUIRED, true);
        execution.setVariable(ProcessVariables.TRIGGER_REASON, triggerReason);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> readFacts(DelegateExecution execution) throws Exception {
        String factsJson = (String) execution.getVariable(ProcessVariables.FACTS_JSON);
        return json.readValue(factsJson == null ? "{}" : factsJson, Map.class);
    }
}
