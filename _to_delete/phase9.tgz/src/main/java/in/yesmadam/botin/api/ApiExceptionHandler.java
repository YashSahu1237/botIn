package in.yesmadam.botin.api;

import in.yesmadam.botin.agent.AgentTaskService.TaskAlreadyClaimedException;
import in.yesmadam.botin.agent.AgentTaskService.TaskNotClaimedException;
import in.yesmadam.botin.agent.AgentTaskService.TaskNotFoundException;
import in.yesmadam.botin.session.HelpSessionService.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * Turns the flow's own failures into answers rather than stack traces.
 *
 * These three are client errors, not server errors: a stale session id, a session
 * that has already ended, input arriving at a step that expects none. Returning 5xx
 * for any of them would put them in the wrong alerting bucket and hide the real ones.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(SessionNotFoundException.class)
    public ResponseEntity<Map<String, String>> notFound(SessionNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("error", "SESSION_NOT_FOUND", "detail", e.getMessage()));
    }

    @ExceptionHandler(SessionClosedException.class)
    public ResponseEntity<Map<String, String>> closed(SessionClosedException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "SESSION_CLOSED", "detail", e.getMessage()));
    }

    @ExceptionHandler(UnexpectedInputException.class)
    public ResponseEntity<Map<String, String>> unexpected(UnexpectedInputException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "UNEXPECTED_INPUT", "detail", e.getMessage()));
    }

    /**
     * A task id that no longer resolves almost always means another agent finished it
     * first. That is a race between two people, not a fault, so it is a 404 with a
     * sentence that says what probably happened.
     */
    @ExceptionHandler(TaskNotFoundException.class)
    public ResponseEntity<Map<String, String>> noTask(TaskNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("error", "AGENT_TASK_NOT_FOUND", "detail", e.getMessage()));
    }

    /** Two agents reached for the same partner. The second one is told whose it is. */
    @ExceptionHandler(TaskAlreadyClaimedException.class)
    public ResponseEntity<Map<String, String>> alreadyClaimed(TaskAlreadyClaimedException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "AGENT_TASK_ALREADY_CLAIMED", "detail", e.getMessage()));
    }

    /** Completing an unclaimed task. The claim is what stops two agents on one partner. */
    @ExceptionHandler(TaskNotClaimedException.class)
    public ResponseEntity<Map<String, String>> notClaimed(TaskNotClaimedException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "AGENT_TASK_NOT_CLAIMED", "detail", e.getMessage()));
    }

    /**
     * Anything else is ours. Log it with the stack, tell the client nothing about it.
     * A partner-facing surface must never leak an internal message.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> unhandled(Exception e) {
        log.error("Unhandled failure serving a help request", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "INTERNAL"));
    }
}
