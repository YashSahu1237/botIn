package in.yesmadam.botin.process;

import in.yesmadam.botin.session.*;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * GATE 1, and the only place it is crossed.
 *
 * A T0 leaves here having created nothing. That is not an optimisation — it is the
 * BRD's central claim made literal: deflected volume does not appear in ticket counts
 * at all, because there is nothing to count. Every tier test from here on asserts it.
 *
 * WHY THE GATE SITS AFTER THE DECISION. Whether a case needs a ticket is a property of
 * the ANSWER, not of the question: the same concern can deflect one partner and require
 * an action for the next. So the ticket cannot be opened when the concern is picked —
 * only once the table has spoken.
 */
@Component("openTicketDelegate")
public class OpenTicketDelegate implements JavaDelegate {

    private static final Logger log = LoggerFactory.getLogger(OpenTicketDelegate.class);

    private final HelpSessionRepository sessions;
    private final TicketRepository tickets;

    public OpenTicketDelegate(HelpSessionRepository sessions, TicketRepository tickets) {
        this.sessions = sessions;
        this.tickets = tickets;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String tier = (String) execution.getVariable(ProcessVariables.TIER);

        if ("T0".equals(tier)) {
            log.debug("T0 — Gate 1 not crossed, no ticket");
            return;
        }

        UUID sessionId = UUID.fromString((String) execution.getVariable(ProcessVariables.HELP_SESSION_ID));
        HelpSession session = sessions.findById(sessionId).orElseThrow(
                () -> new IllegalStateException("no help session " + sessionId));

        Ticket ticket = Ticket.openAtGate1(session);
        ticket.recordDecision(tier, (String) execution.getVariable(ProcessVariables.ACTION));

        if (Boolean.TRUE.equals(execution.getVariable(ProcessVariables.AGENT_REQUIRED))) {
            // Sets tier T3, the trigger, and status AWAITING_AGENT in one move — the
            // ticket is not "open and also escalated", it is waiting for a person.
            ticket.escalate((String) execution.getVariable(ProcessVariables.TRIGGER_REASON));
        }

        tickets.saveAndFlush(ticket);
        execution.setVariable(ProcessVariables.TICKET_ID, ticket.getId().toString());

        log.info("Gate 1 crossed: ticket {} for session {} tier={} status={}",
                ticket.getId(), sessionId, ticket.getTier(), ticket.getStatus());
    }
}
