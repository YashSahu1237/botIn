package in.yesmadam.botin.session;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.UUID;

public interface TicketRepository extends JpaRepository<Ticket, UUID> {

    /** Agent-connect trigger D: same SP, same sub-concern, inside a window. */
    long countBySpIdAndL2ConcernAndCreatedAtAfter(String spId, String l2Concern, Instant since);

    /**
     * Every ticket ever opened against one partner.
     *
     * Exists for the Gate 1 checkpoints. "This partner's journey filed nothing" is the
     * claim a deflection actually makes, and it is provable per partner without
     * depending on the rest of the database being empty — which, in a suite whose money
     * tests commit on purpose, it never is.
     */
    long countBySpId(String spId);

    /** Gate 1, per session. A T0 session must never have one of these. */
    long countByHelpSessionId(UUID helpSessionId);
}
