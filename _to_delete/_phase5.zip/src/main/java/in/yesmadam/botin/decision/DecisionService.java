package in.yesmadam.botin.decision;

import org.flowable.dmn.api.DmnDecisionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * The only way to evaluate a decision table.
 *
 * Everything about how the tables behave was established by spike 2, and two findings
 * are enforced here rather than left to good intentions:
 *
 *   1. Hit policy is FIRST, so ROW ORDER IS LOGIC. A row moved is a behaviour change.
 *   2. A case matching NO row returns null — not a default, not an error. Every table
 *      ends in a catch-all for that reason, and this class refuses a null result loudly
 *      instead of handing a null tier to a gateway that cannot branch on it.
 */
@Service
public class DecisionService {

    private static final Logger log = LoggerFactory.getLogger(DecisionService.class);

    private final DmnDecisionService dmn;

    public DecisionService(DmnDecisionService dmn) {
        this.dmn = dmn;
    }

    public Decision decide(String decisionKey, Map<String, Object> facts) {
        Map<String, Object> result = dmn.createExecuteDecisionBuilder()
                .decisionKey(decisionKey)
                .variables(facts)
                .executeWithSingleResult();

        if (result == null) {
            // Only reachable if a table lost its catch-all. Failing here is the whole
            // point: the alternative is a null tier reaching a gateway, which in spike 2
            // produced no error anywhere.
            throw new NoMatchingRuleException(decisionKey, facts);
        }

        Decision decision = new Decision(
                str(result.get("tier")),
                str(result.get("action")),
                str(result.get("outcomeType")),
                result);

        log.debug("{} -> tier={} action={} type={}",
                decisionKey, decision.tier(), decision.action(), decision.outcomeType());
        return decision;
    }

    private static String str(Object o) { return o == null ? null : o.toString(); }

    public static class NoMatchingRuleException extends RuntimeException {
        public NoMatchingRuleException(String decisionKey, Map<String, Object> facts) {
            super("Decision table '" + decisionKey + "' matched no rule and has no catch-all. Facts: " + facts);
        }
    }
}
