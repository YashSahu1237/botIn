package in.yesmadam.botin.facts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * WORKED EXAMPLE — the anchor concern. Reads UAT, writes nothing, decides nothing.
 *
 * =========================================================================
 * TABLE AND COLUMN NAMES BELOW ARE PLACEHOLDERS.
 *
 * Every query is marked TODO(schema). Replace with the real UAT names and
 * nothing else in the service changes — that is the whole reason to read a
 * production-shaped database rather than a synthetic one: the SQL written here
 * is the SQL that ships.
 * =========================================================================
 *
 * transportPath is DERIVED, and that derivation is an ASSUMPTION. The mapping
 * labels rules Path 1/2/3 but never says what assigns a claim to a path. The
 * reading taken here: Path 1 = a customer transport charge that never reached
 * the partner; Path 2 = the booking was cancelled; Path 3 = travel beyond the
 * hub radius. Recorded in the plan as a workaround, pending the real rule.
 */
@Component
public class TransportFactProvider implements ConcernFactProvider {

    private static final Logger log = LoggerFactory.getLogger(TransportFactProvider.class);

    private final JdbcTemplate uat;   // null when botin.uat.enabled=false
    private final TransportPathSelector pathSelector;

    public TransportFactProvider(@Autowired(required = false)
                                 @Qualifier("uatJdbcTemplate") JdbcTemplate uat,
                                 TransportPathSelector pathSelector) {
        this.uat = uat;
        this.pathSelector = pathSelector;
    }

    @Override
    public String concernCode() {
        return "TRANSPORT_NOT_RECEIVED";
    }

    @Override
    public Map<String, Object> fetchFacts(FactRequest request) {
        Map<String, Object> facts = new HashMap<>();

        if (uat == null) {
            log.warn("UAT datasource disabled — returning no facts for {}. The decision table "
                   + "will fall to its catch-all, which is correct but is NOT a business outcome.",
                     request.ticketId());
            facts.put("factsAvailable", false);
            return facts;
        }

        String orderId = request.selectedReference();

        // TODO(schema): real table/column names for the transport ledger entry.
        Boolean alreadyCredited = uat.queryForObject(
            "SELECT EXISTS (SELECT 1 FROM sp_wallet_txn " +          // TODO(schema)
            "               WHERE order_id = ? AND txn_type = 'TRANSPORT')",
            Boolean.class, orderId);

        // TODO(schema): was the customer charged a transport component on this order.
        Boolean customerCharged = uat.queryForObject(
            "SELECT EXISTS (SELECT 1 FROM booking_charge " +          // TODO(schema)
            "               WHERE order_id = ? AND charge_type = 'TRANSPORT')",
            Boolean.class, orderId);

        // TODO(schema): the 300-metre arrival event — the proof the partner travelled.
        Boolean arrived = uat.queryForObject(
            "SELECT EXISTS (SELECT 1 FROM booking_event " +           // TODO(schema)
            "               WHERE order_id = ? AND event_type = 'ARRIVED_AT_300M')",
            Boolean.class, orderId);

        // TODO(schema): cancellation status — NR / AGENT / CR, or null if not cancelled.
        String cancellationStatus = uat.query(
            "SELECT cancellation_type FROM booking WHERE order_id = ?",   // TODO(schema)
            rs -> rs.next() ? rs.getString(1) : null, orderId);

        facts.put("factsAvailable", true);
        facts.put("alreadyCredited", Boolean.TRUE.equals(alreadyCredited));
        facts.put("customerTransportCharged", Boolean.TRUE.equals(customerCharged));
        facts.put("arrivedAt300metre", Boolean.TRUE.equals(arrived));
        facts.put("cancellationStatus", cancellationStatus);
        facts.put("transportPath", pathSelector.select(customerCharged, alreadyCredited, cancellationStatus));

        // TODO(schema): hub centre lat/long + radius, job lat/long -> haversine.
        // Deferred to Phase 4 with the shared geo service; Path 3 is unreachable
        // until then, and the table's catch-all covers it.

        return facts;
    }

}
