package in.yesmadam.botin.facts;

import in.yesmadam.botin.facts.shared.DeliveryTatService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * PROD_DELIVERY_DELAY — 2,306/month, second highest in the build. "Where is my order?"
 *
 * Reads the SHARED TAT service, and that is the point rather than a convenience. The
 * parked VIOL_R9_NO_PRODUCT reads the same one. If the two ever computed "late"
 * differently, the same partner would be told their order is on time AND that they should
 * already have had it.
 *
 * EXPRESS IS DECIDED BY PINCODE, not by anything on the order. The live system keeps the
 * list in tbl_settings under express_delivery_pincodes, loaded here rather than guessed.
 */
@Component
public class ProductDeliveryFactProvider implements ConcernFactProvider {

    private static final Logger log = LoggerFactory.getLogger(ProductDeliveryFactProvider.class);

    /** The partner's most recent product order. delivered_at non-null means it arrived. */
    private static final String ORDER_SQL = """
            SELECT created_at, delivered_at, order_status_code
            FROM ysmdm_admin.tbl_sp_order
            WHERE spid = ? ORDER BY id DESC LIMIT 1""";

    /** The Express pincode list, as the live system stores it: one settings row. */
    private static final String EXPRESS_PINCODES_SQL = """
            SELECT value FROM ysmdm_admin.tbl_settings WHERE name = 'express_delivery_pincodes'""";

    private final JdbcTemplate uat;
    private final DeliveryTatService tat;

    public ProductDeliveryFactProvider(@Autowired(required = false) @Qualifier("uatJdbcTemplate") JdbcTemplate uat,
                                       DeliveryTatService tat) {
        this.uat = uat;
        this.tat = tat;
    }

    @Override public String concernCode() { return "PROD_DELIVERY_DELAY"; }

    @Override public Set<String> factKeys() { return Set.of("pastElevenPmDeadline"); }

    @Override public List<UatColumn> requiredColumns() {
        return List.of(
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_order", "spid"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_order", "created_at"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_order", "delivered_at"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_order", "order_status_code"),
            // tbl_settings is a key/value table; the column names are INFERRED, and the
            // KEY NAME came from an error string in empapi, not from a schema.
            UatColumn.inferred("ysmdm_admin", "tbl_settings", "name"),
            UatColumn.inferred("ysmdm_admin", "tbl_settings", "value"));
    }

    @Override
    public Map<String, Object> fetchFacts(FactRequest request) {
        Map<String, Object> facts = emptyFacts();
        if (uat == null) return facts;

        Timestamp placedAt = uat.query(ORDER_SQL,
                rs -> rs.next() ? rs.getTimestamp("created_at") : null, request.spId());

        if (placedAt == null) {
            // No order at all, or none we could read. NOT "on time" — null, which the
            // table sends to a human. Telling a partner with no order to keep waiting is
            // worse than admitting we do not know.
            log.debug("no product order found for {}", request.spId());
            return facts;
        }

        // The partner's pincode is not on tbl_sp_order. tbl_sp_address_book exists and is
        // the likely source, but the linking column is unconfirmed, so Express cannot yet
        // be determined and everything is assessed on the STANDARD TAT — the slower,
        // more forgiving of the two. A partner is never told "late" earlier than they
        // should be by this gap.
        // TODO(schema): which column links tbl_sp_order to the partner's delivery pincode?
        boolean express = false;

        ZonedDateTime placed = placedAt.toInstant().atZone(DeliveryTatService.ZONE);
        facts.put("pastElevenPmDeadline", tat.isPastTat(placed, express));
        return facts;
    }

    /** Loaded lazily so a malformed settings row degrades this concern, not the boot. */
    Set<String> expressPincodes() {
        if (uat == null) return Set.of();
        try {
            String csv = uat.query(EXPRESS_PINCODES_SQL,
                    rs -> rs.next() ? rs.getString("value") : null);
            if (csv == null || csv.isBlank()) return Set.of();
            return new HashSet<>(Arrays.stream(csv.split("[,\\s]+"))
                    .filter(s -> !s.isBlank()).map(String::trim).toList());
        } catch (Exception e) {
            log.error("could not read express_delivery_pincodes — treating every order as Standard", e);
            return Set.of();
        }
    }
}
