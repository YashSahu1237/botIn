package in.yesmadam.botin.facts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

/**
 * The two concerns whose decision is "is this actually a different concern?" —
 * VIOL_R4_OTHERS and OTHER_FREETEXT_TRIAGE. Both read the same two facts from the
 * classifier, so one class serves both rather than two that must be kept in step.
 *
 * THE CLASSIFIER DOES NOT EXIST YET. It is Phase 11, and the LLM track is blocked on
 * procurement. Until it exists this returns classificationMatched = false with zero
 * confidence, which routes every free-text case to a human.
 *
 * That is the right behaviour, not a placeholder: a wrong reroute costs the partner an
 * entire second journey through the wrong flow, so the absence of a classifier must read
 * as "no confident match" and never as "no opinion". The value is set explicitly rather
 * than left null for exactly that reason — null would reach the same catch-all, but by
 * accident rather than by decision.
 */
@Component
public class ClassifierFactProvider {

    private static final Logger log = LoggerFactory.getLogger(ClassifierFactProvider.class);

    static Map<String, Object> notYetClassified(ConcernFactProvider self, FactRequest request) {
        Map<String, Object> facts = self.emptyFacts();
        facts.put("classificationMatched", false);
        facts.put("classifierConfidence", 0.0);
        log.debug("no classifier yet — {} routes to a human for session text of {} chars",
                self.concernCode(), request.freeText() == null ? 0 : request.freeText().length());
        return facts;
    }

    static Set<String> classifierKeys() {
        return Set.of("classificationMatched", "classifierConfidence");
    }

    /** VIOL_R4_OTHERS — the partner picked "other" on a violation appeal and typed a reason. */
    @Component
    public static class ViolationOthers implements ConcernFactProvider {
        @Override public String concernCode() { return "VIOL_R4_OTHERS"; }
        @Override public Set<String> factKeys() { return classifierKeys(); }
        @Override public Map<String, Object> fetchFacts(FactRequest r) { return notYetClassified(this, r); }
    }

    /** OTHER_FREETEXT_TRIAGE — the partner typed something before picking anything at all. */
    @Component
    public static class FreeTextTriage implements ConcernFactProvider {
        @Override public String concernCode() { return "OTHER_FREETEXT_TRIAGE"; }
        @Override public Set<String> factKeys() { return classifierKeys(); }
        @Override public Map<String, Object> fetchFacts(FactRequest r) { return notYetClassified(this, r); }
    }
}
