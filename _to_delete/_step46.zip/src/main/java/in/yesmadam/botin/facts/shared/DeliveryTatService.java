package in.yesmadam.botin.facts.shared;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.Set;

/**
 * PLAN STEP 43. The ONE definition of "is this product order late".
 *
 * TWO CONCERNS READ THIS AND THEY MUST NEVER DISAGREE:
 *
 *   PROD_DELIVERY_DELAY  - the partner asks where their order is      (2,306/month)
 *   VIOL_R9_NO_PRODUCT   - the partner is fined for not having it
 *
 * If those two ever compute "late" differently, the same partner is told their order
 * is on time AND that they should have had it. The concern mapping flags this
 * explicitly: R9 must use the shared TAT, NOT a flat three days. A later checkpoint
 * changes the rule here once and asserts both concerns move together.
 *
 * WHAT THE LIVE SYSTEM SAYS, from reading empapi:
 *
 *   - Express eligibility is decided by PINCODE, from tbl_settings under the key
 *     express_delivery_pincodes. It is NOT a flag on the order.
 *   - The existing ticketing concern is literally named
 *     TEEN_DIN_SE_JYADA_HO_GAYE_PRODUCT_NAHI_AAYA - "more than three days have
 *     passed" - which is evidence that three days is today's standard TAT.
 *
 * ASSUMPTIONS, both configurable and both needing confirmation:
 *   - Standard TAT is 3 days, Express 1. Taken from the concern name above.
 *   - The 11 PM cut-off works as an ORDERING deadline: an order placed at or after
 *     23:00 starts its clock the next day, and the TAT expires at 23:00 on the last
 *     day. The mapping says "the 11 PM deadline for its TAT" without defining which.
 */
@Service
public class DeliveryTatService {

    /** Everything here happens in India. Stating it beats inheriting the server's default. */
    public static final ZoneId ZONE = ZoneId.of("Asia/Kolkata");

    private final int standardDays;
    private final int expressDays;
    private final int cutoffHour;

    public DeliveryTatService(@Value("${botin.tat.standard-days:3}") int standardDays,
                              @Value("${botin.tat.express-days:1}") int expressDays,
                              @Value("${botin.tat.cutoff-hour:23}") int cutoffHour) {
        this.standardDays = standardDays;
        this.expressDays = expressDays;
        this.cutoffHour = cutoffHour;
    }

    /**
     * Express is a property of WHERE the partner is, not of the order.
     *
     * @param expressPincodes the list from tbl_settings.express_delivery_pincodes
     */
    public boolean isExpress(String pincode, Set<String> expressPincodes) {
        if (pincode == null || expressPincodes == null) return false;
        return expressPincodes.contains(pincode.trim());
    }

    /**
     * The instant after which the order is late.
     *
     * Placed before the cut-off: the clock starts that day. Placed at or after it: the
     * clock starts tomorrow, because nothing ships after the cut-off. The deadline
     * itself is the cut-off hour on the final day.
     */
    public ZonedDateTime deadline(ZonedDateTime placedAt, boolean express) {
        if (placedAt == null) return null;

        ZonedDateTime local = placedAt.withZoneSameInstant(ZONE);
        LocalDate clockStarts = local.toLocalDate();
        if (local.getHour() >= cutoffHour) {
            clockStarts = clockStarts.plusDays(1);
        }

        LocalDate due = clockStarts.plusDays(express ? expressDays : standardDays);
        return due.atTime(cutoffHour, 0).atZone(ZONE);
    }

    /** The date a partner should be told to expect, for the T1 "please wait" reply. */
    public LocalDate expectedDeliveryDate(ZonedDateTime placedAt, boolean express) {
        ZonedDateTime d = deadline(placedAt, express);
        return d == null ? null : d.toLocalDate();
    }

    /**
     * Is the order past its TAT right now?
     *
     * @return null when the order date is unknown. Null is NOT false: false means "on
     *         time, tell them to wait", and saying that about an order we cannot date
     *         is a guess dressed as an answer. The decision tables send null to a human.
     */
    public Boolean isPastTat(ZonedDateTime placedAt, boolean express, ZonedDateTime now) {
        if (placedAt == null || now == null) return null;
        ZonedDateTime deadline = deadline(placedAt, express);
        return now.isAfter(deadline);
    }

    /** Convenience for callers that only have a delivered/not-delivered picture. */
    public Boolean isPastTat(ZonedDateTime placedAt, boolean express) {
        return isPastTat(placedAt, express, ZonedDateTime.now(ZONE));
    }

    public int standardDays() { return standardDays; }
    public int expressDays()  { return expressDays; }
    public int cutoffHour()   { return cutoffHour; }
}
