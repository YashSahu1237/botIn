package in.yesmadam.botin.facts;

import in.yesmadam.botin.facts.shared.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * TRANSPORT_NOT_RECEIVED — 5,615/month, the highest-volume concern in the build and the
 * only one that pays on three different bases.
 *
 * CROSSES TWO CATALOGS. The booking lives in ysmdm_users, the partner's wallet ledger in
 * ysmdm_admin. Both are on one MySQL instance, so the SQL qualifies the catalog and one
 * connection serves both.
 *
 * selectedReference is the ORDER ID. Without it nothing can be looked up, and the facts
 * come back all-null — which the table sends to a human rather than guessing.
 */
@Component
public class TransportFactProvider implements ConcernFactProvider {

    private static final Logger log = LoggerFactory.getLogger(TransportFactProvider.class);

    /** The booking. arrivedAt300M is a TIMESTAMP — non-null means the partner arrived. */
    private static final String ORDER_SQL = """
            SELECT transport_charges, arrived_at300_m, unassign_status_code,
                   order_status_code, cashback, hub_id
            FROM ysmdm_users.tbl_order WHERE order_id = ?""";

    /** The wallet ledger for this order. CREDIT and DEBIT both occur — see the net rule. */
    private static final String LEDGER_SQL = """
            SELECT action, subaction, amount
            FROM ysmdm_admin.tbl_sp_tranactions
            WHERE orderid = ? AND subaction = 'TRANSPORT'""";

    /** The hub's position, and the slab ends its radius is derived from. */
    private static final String HUB_SQL = """
            SELECT h.lat, h.lng FROM ysmdm_admin.tbl_hub h WHERE h.id = ?""";
    private static final String SLABS_SQL = """
            SELECT t.end FROM ysmdm_admin.tbl_servicehub_transportation t WHERE t.hub_id = ?""";

    private final JdbcTemplate uat;   // null when botin.uat.enabled=false
    private final TransportPathSelector pathSelector;
    private final DuplicateCreditGuard creditGuard;
    private final GeoService geo;

    public TransportFactProvider(@Autowired(required = false) @Qualifier("uatJdbcTemplate") JdbcTemplate uat,
                                 TransportPathSelector pathSelector,
                                 DuplicateCreditGuard creditGuard,
                                 GeoService geo) {
        this.uat = uat;
        this.pathSelector = pathSelector;
        this.creditGuard = creditGuard;
        this.geo = geo;
    }

    @Override public String concernCode() { return "TRANSPORT_NOT_RECEIVED"; }

    @Override public Set<String> factKeys() {
        return Set.of("alreadyCredited", "computedAmountPaise", "transportPath",
                      "arrivedAt300metre", "cancellationStatus",
                      "lastMinCashbackCredited", "distanceBeyondRadiusKm");
    }

    @Override public List<UatColumn> requiredColumns() {
        return List.of(
            UatColumn.confirmed("ysmdm_users", "tbl_order", "order_id"),
            UatColumn.confirmed("ysmdm_users", "tbl_order", "transport_charges"),
            UatColumn.confirmed("ysmdm_users", "tbl_order", "order_status_code"),
            UatColumn.confirmed("ysmdm_users", "tbl_order", "unassign_status_code"),
            UatColumn.confirmed("ysmdm_users", "tbl_order", "cashback"),
            UatColumn.confirmed("ysmdm_users", "tbl_order", "hub_id"),
            // camelCase field with no @Column in empapi — physical name INFERRED.
            UatColumn.inferred ("ysmdm_users", "tbl_order", "arrived_at300_m"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_tranactions", "action"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_tranactions", "subaction"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_tranactions", "orderid"),
            UatColumn.confirmed("ysmdm_admin", "tbl_sp_tranactions", "amount"),
            // GeoCode is @Embeddable on tbl_hub — column names INFERRED.
            UatColumn.inferred ("ysmdm_admin", "tbl_hub", "lat"),
            UatColumn.inferred ("ysmdm_admin", "tbl_hub", "lng"),
            UatColumn.confirmed("ysmdm_admin", "tbl_servicehub_transportation", "end"));
    }

    @Override
    public Map<String, Object> fetchFacts(FactRequest request) {
        Map<String, Object> facts = emptyFacts();
        if (uat == null || request.selectedReference() == null) {
            log.debug("transport facts unavailable — uat={} ref={}",
                    uat != null, request.selectedReference());
            return facts;
        }

        Long orderId = asLong(request.selectedReference());
        if (orderId == null) return facts;

        Map<String, Object> order = uat.query(ORDER_SQL,
                rs -> rs.next() ? Map.of(
                        "transportCharges", (Object) rs.getInt("transport_charges"),
                        "arrivedAt300M",    rs.getTimestamp("arrived_at300_m") != null,
                        "unassignCode",     rs.getInt("unassign_status_code"),
                        "cashback",         rs.getInt("cashback"),
                        "hubId",            rs.getInt("hub_id"))
                    : null, orderId);
        if (order == null) return facts;

        // Net position, never EXISTS(CREDIT): DEBIT/TRANSPORT is real, so a reversed
        // credit must not read as paid. See DuplicateCreditGuard.
        List<LedgerEntry> ledger = uat.query(LEDGER_SQL,
                (rs, i) -> new LedgerEntry(rs.getString("action"), rs.getString("subaction"),
                        rs.getLong("amount")), orderId);
        boolean alreadyCredited = creditGuard.alreadyCredited(ledger, "TRANSPORT");

        String cancellationStatus = cancellationOf((Integer) order.get("unassignCode"));
        boolean charged = ((Integer) order.get("transportCharges")) > 0;

        facts.put("alreadyCredited", alreadyCredited);
        facts.put("arrivedAt300metre", order.get("arrivedAt300M"));
        facts.put("cancellationStatus", cancellationStatus);
        facts.put("lastMinCashbackCredited", ((Integer) order.get("cashback")) > 0);
        facts.put("transportPath", pathSelector.select(charged, alreadyCredited, cancellationStatus));
        facts.put("distanceBeyondRadiusKm", beyondRadius((Integer) order.get("hubId")));

        // computedAmountPaise stays null until the rate question is settled — see
        // docs/DEFERRED.md D-B. Null means the cap row cannot fire, and the paying rows
        // it guards are exactly the ones that need the answer first.
        return facts;
    }

    /**
     * UnAssignStatus in the live enum: REJECT=1, CANCEL=2, UNASSIGN=3,
     * UNASSIGN_WITH_REMOVE_SP=4. The decision table speaks in NR / BY_AGENT / CR.
     *
     * MAPPING UNCONFIRMED. tbl_order also carries nrTicketCount and crTicketCount, so NR
     * and CR exist as first-class concepts somewhere other than this column. Until the
     * mapping is confirmed, only the cases that are unambiguous are named; anything else
     * stays null and reaches a human.
     */
    private String cancellationOf(Integer unassignCode) {
        if (unassignCode == null || unassignCode == 0) return null;
        return switch (unassignCode) {
            case 3, 4 -> "CANCELLED_BY_AGENT";   // unassigned by the business
            default   -> null;                   // TODO(confirm): which code is NR, which CR
        };
    }

    private Double beyondRadius(Integer hubId) {
        if (hubId == null) return null;
        List<Double> slabEnds = uat.query(SLABS_SQL, (rs, i) -> rs.getDouble("end"), hubId);
        Double radiusKm = HubGeometry.radiusFromSlabEnds(slabEnds);
        if (radiusKm == null) return null;

        HubGeometry hub = uat.query(HUB_SQL,
                rs -> rs.next() ? HubGeometry.of(rs.getString("lat"), rs.getString("lng"), radiusKm)
                                : null, hubId);
        if (hub == null) return null;

        // THE HUB IS KNOWN; THE JOB IS NOT. tbl_order carries no latitude or longitude.
        // tbl_fifty_metre_radius_log has lat/lng per order_id, but those record where the
        // PARTNER was, not where the job is — measuring hub-to-partner would pay for the
        // distance they happened to be standing at, which is not the rule.
        //
        // So Path 3 cannot be measured yet and returns null, not zero. Zero would read as
        // "inside the hub" and DENY every Path 3 claim without assessing one.
        // TODO(schema): where is the job's own latitude/longitude?
        log.debug("hub {} geometry resolved (radius {} km) but the job location is not "
                + "available — Path 3 cannot be measured", hubId, hub.radiusKm());
        return null;
    }

    private static Long asLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return null; }
    }
}
