package in.yesmadam.botin.facts.shared;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.*;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/** PLAN STEP 43. Dates and a cut-off hour. No Spring, no database. */
class DeliveryTatServiceTest {

    // Standard 3 days, Express 1, cut-off 23:00 — the configured defaults.
    private final DeliveryTatService tat = new DeliveryTatService(3, 1, 23);

    private static ZonedDateTime at(int day, int hour) {
        return ZonedDateTime.of(LocalDate.of(2026, 9, day), LocalTime.of(hour, 0),
                DeliveryTatService.ZONE);
    }

    @Test
    @DisplayName("Express is decided by PINCODE, not by anything on the order")
    void expressComesFromThePincodeList() {
        Set<String> express = Set.of("110001", "560001");
        assertTrue(tat.isExpress("110001", express));
        assertTrue(tat.isExpress(" 110001 ", express), "whitespace is survivable");
        assertFalse(tat.isExpress("700001", express));
        assertFalse(tat.isExpress(null, express));
        assertFalse(tat.isExpress("110001", null));
    }

    @Test
    @DisplayName("placed before the cut-off: the clock starts that same day")
    void beforeCutoffStartsToday() {
        // 1 Sep at 10:00, standard 3 days -> due 4 Sep at 23:00.
        ZonedDateTime deadline = tat.deadline(at(1, 10), false);
        assertEquals(LocalDate.of(2026, 9, 4), deadline.toLocalDate());
        assertEquals(23, deadline.getHour());
    }

    @Test
    @DisplayName("placed AT or after the cut-off: the clock starts tomorrow")
    void atOrAfterCutoffStartsTomorrow() {
        // Exactly 23:00 already counts as after — nothing ships at the deadline itself.
        assertEquals(LocalDate.of(2026, 9, 5), tat.deadline(at(1, 23), false).toLocalDate());
        assertEquals(LocalDate.of(2026, 9, 5), tat.deadline(at(1, 23).plusMinutes(30), false).toLocalDate());
    }

    @Test
    @DisplayName("Express is one day, Standard is three")
    void expressIsFaster() {
        assertEquals(LocalDate.of(2026, 9, 2), tat.deadline(at(1, 10), true).toLocalDate());
        assertEquals(LocalDate.of(2026, 9, 4), tat.deadline(at(1, 10), false).toLocalDate());
    }

    @Test
    @DisplayName("on time right up to the deadline, late one second after")
    void theBoundaryIsExact() {
        ZonedDateTime placed = at(1, 10);
        ZonedDateTime deadline = tat.deadline(placed, false);

        assertFalse(tat.isPastTat(placed, false, deadline), "AT the deadline is still on time");
        assertFalse(tat.isPastTat(placed, false, deadline.minusMinutes(1)));
        assertTrue(tat.isPastTat(placed, false, deadline.plusSeconds(1)));
    }

    @Test
    @DisplayName("BOTH concerns get the same answer from the same call")
    void oneDefinitionServesBothConcerns() {
        // PROD_DELIVERY_DELAY asks "where is my order"; VIOL_R9_NO_PRODUCT asks "should
        // they have had it". Same inputs, same call, so they cannot disagree and tell
        // one partner two different things.
        ZonedDateTime placed = at(1, 10);
        ZonedDateTime now = at(6, 12);

        Boolean forDeliveryDelay = tat.isPastTat(placed, false, now);
        Boolean forViolationR9   = tat.isPastTat(placed, false, now);

        assertEquals(forDeliveryDelay, forViolationR9);
        assertTrue(forDeliveryDelay);
    }

    @Test
    @DisplayName("an undated order returns NULL, which is not the same as on time")
    void unknownDateIsNull() {
        // False means "on time, tell them to wait". Saying that about an order we cannot
        // date is a guess dressed as an answer. Null reaches the catch-all, then a human.
        assertNull(tat.isPastTat(null, false, at(1, 10)));
        assertNull(tat.isPastTat(at(1, 10), false, null));
        assertNull(tat.deadline(null, false));
        assertNull(tat.expectedDeliveryDate(null, false));
    }

    @Test
    @DisplayName("the timezone is stated, not inherited from whatever the server is set to")
    void timezoneIsExplicit() {
        assertEquals(ZoneId.of("Asia/Kolkata"), DeliveryTatService.ZONE);

        // Same instant, expressed in UTC. The answer must not change.
        ZonedDateTime sameInstantUtc = at(1, 10).withZoneSameInstant(ZoneId.of("UTC"));
        assertEquals(tat.deadline(at(1, 10), false), tat.deadline(sameInstantUtc, false));
    }
}
