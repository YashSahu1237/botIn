package in.yesmadam.botin.process;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.yesmadam.botin.api.dto.NextStep;
import in.yesmadam.botin.session.HelpSession;
import in.yesmadam.botin.session.HelpSessionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * The one place a process is allowed to tell the client what happens next.
 *
 * THE TRAP THIS EXISTS TO AVOID. A delegate's obvious move is to set a process
 * variable and let the caller read it back after startProcessInstanceByKey returns.
 * That works right up until the process completes synchronously — which every T0
 * does — because a completed instance has its ACT_RU_* rows deleted, variables
 * included. The read returns null, and it returns null only for the flows that
 * finish quickly, which is exactly the set that looks fine in a demo.
 *
 * So every process writes its ending HERE, onto the help_session row, and the API
 * layer re-reads it from there. Spike 1 is what established this.
 */
@Component
public class SessionStepWriter {

    private static final Logger log = LoggerFactory.getLogger(SessionStepWriter.class);

    private final HelpSessionRepository sessions;
    private final ObjectMapper json;

    public SessionStepWriter(HelpSessionRepository sessions, ObjectMapper json) {
        this.sessions = sessions;
        this.json = json;
    }

    /**
     * Write the ending and close the session. Used by every terminal outcome — a
     * deflection, a resolution, an upheld appeal.
     *
     * @param terminalStatus the status to close with, so the reason survives on the
     *                       row. CLOSED_DEFLECTED and CLOSED_RESOLVED are different
     *                       facts and the rollout needs to count them separately.
     */
    public void writeAndClose(UUID sessionId, NextStep step, String terminalStatus) {
        HelpSession session = sessions.findById(sessionId).orElseThrow(
                () -> new IllegalStateException("process referenced a session that does not exist: " + sessionId));

        session.setNextStep(step.type().name(), serialise(step));
        session.setCurrentStep("ENDED");
        session.closeAs(terminalStatus);
        sessions.save(session);

        log.info("session {} ended: {} / {}", sessionId, terminalStatus, step.code());
    }

    private String serialise(NextStep step) {
        try {
            return json.writeValueAsString(step);
        } catch (JsonProcessingException e) {
            // Better to fail the process than to close a session with an unreadable
            // ending — the partner would see nothing and the row would look fine.
            throw new IllegalStateException("nextStep is not serialisable: " + step, e);
        }
    }
}
