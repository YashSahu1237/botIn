package in.yesmadam.botin.process;

/**
 * The variables every concern process is started with.
 *
 * Kept as constants because a typo in a variable name is not a compile error and
 * not a runtime error either — the delegate simply reads null and behaves as if the
 * partner had given nothing. Same failure shape as the Togglz hole in spike 4.
 */
public final class ProcessVariables {

    /** The help_session id. Every delegate needs it to write its ending. */
    public static final String HELP_SESSION_ID = "helpSessionId";

    public static final String SP_ID = "spId";
    public static final String L2_CONCERN = "l2Concern";

    /** Whatever the partner selected from a DROPDOWN — a booking, an order, a violation. */
    public static final String SELECTED_REFERENCE = "selectedReference";

    private ProcessVariables() { }
}
