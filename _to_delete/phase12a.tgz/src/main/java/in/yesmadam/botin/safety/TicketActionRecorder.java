package in.yesmadam.botin.safety;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

/**
 * ADR-005 — the most load-bearing class in the service.
 *
 * A Flowable Service Task runs inside the engine's transaction. If a LATER node
 * throws, the engine rolls back — and by default that takes this record with it,
 * while the external system it describes does NOT roll back. Money moved, no
 * evidence, and reconciliation has nothing to detect.
 *
 * REQUIRES_NEW suspends the engine's transaction, commits this row in its own,
 * and returns. Only then does the caller make the external call.
 *
 * PROVEN in the R&D ladder, in both directions: with the annotation the row
 * survives a rollback, without it the row is lost.
 *
 * ---------------------------------------------------------------------------
 * TRAP: Spring applies @Transactional through a proxy. A call from INSIDE this
 * class to another of its own methods silently ignores the annotation — no
 * error, no warning, and the money record quietly stops being protected. Always
 * call these from another bean.
 *
 * TODO(before Phase 4): re-run the rollback test once the UAT datasource is
 * wired. A second datasource changes which transaction manager Spring selects,
 * and a wrongly wired one breaks REQUIRES_NEW with no error at all.
 * ---------------------------------------------------------------------------
 */
@Service
public class TicketActionRecorder {

    private static final Logger log = LoggerFactory.getLogger(TicketActionRecorder.class);

    private final TicketActionRepository repository;

    public TicketActionRecorder(TicketActionRepository repository) {
        this.repository = repository;
    }

    /**
     * Commits an ATTEMPTED row in its own transaction, BEFORE the external call.
     *
     * @return empty when this exact action was already attempted — the caller
     *         must then short-circuit rather than act again. That is the
     *         idempotency guarantee, enforced by a unique constraint rather
     *         than by a check-then-act race.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Optional<TicketAction> recordAttempt(UUID ticketId, String actionType,
                                                Long amountPaise, String requestPayload) {
        return recordAttempt(ticketId, actionType, null, amountPaise, requestPayload);
    }

    /**
     * @param externalReference the THIRD PARTY's id for the thing being acted on — the
     *        gateway's order reference, not ours. Supply it wherever one exists.
     *
     *        Without it this guard protects retries of THIS ticket and nothing else,
     *        and the case that actually happens is the other one: a partner re-raising
     *        the same complaint next week gets a new session, a new ticket, a different
     *        key, and a second payment. See TicketAction.idempotencyKey.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Optional<TicketAction> recordAttempt(UUID ticketId, String actionType, String externalReference,
                                                Long amountPaise, String requestPayload) {
        String key = TicketAction.idempotencyKey(ticketId, actionType, externalReference);

        Optional<TicketAction> existing = repository.findByIdempotencyKey(key);
        if (existing.isPresent()) {
            log.info("action already attempted, short-circuiting key={} status={}",
                     key, existing.get().getStatus());
            return Optional.empty();
        }

        TicketAction attempt = repository.saveAndFlush(
                TicketAction.attempt(ticketId, actionType, externalReference, amountPaise, requestPayload));
        log.info("recorded ATTEMPTED in its own transaction key={}", key);
        return Optional.of(attempt);
    }

    /** Outcome write. Also REQUIRES_NEW: it must not be lost to a later rollback either. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void recordOutcome(UUID actionId, boolean success, String responsePayload) {
        repository.findById(actionId).ifPresent(a -> {
            if (success) a.succeeded(responsePayload); else a.failed(responsePayload);
            repository.saveAndFlush(a);
        });
    }
}
