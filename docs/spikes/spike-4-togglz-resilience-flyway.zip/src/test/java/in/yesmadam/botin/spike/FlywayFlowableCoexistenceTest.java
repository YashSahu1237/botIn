package in.yesmadam.botin.spike;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 4c — do Flyway and Flowable fight over the schema?
 *
 * Flyway owns our tables. Flowable creates its own ~25 ACT_* tables through its
 * own mechanism and knows nothing about Flyway. If they collide, the real service
 * cannot use both — and every other spike result stops mattering.
 *
 * Hibernate ddl-auto is OFF here on purpose: if it were on, it would create our
 * tables and the test would pass without Flyway doing anything.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:flywayspike;DB_CLOSE_DELAY=-1",
    "spring.flyway.enabled=true",
    "spring.jpa.hibernate.ddl-auto=none"
})
class FlywayFlowableCoexistenceTest {

    @Autowired JdbcTemplate jdbc;
    @Autowired AttemptRecordRepository repo;

    @Test
    @DisplayName("Flyway created our tables")
    void flywayRanTheMigration() {
        Integer migrations = jdbc.queryForObject(
                "SELECT COUNT(*) FROM flyway_schema_history WHERE success = TRUE", Integer.class);
        assertNotNull(migrations);
        assertTrue(migrations >= 1, "flyway_schema_history should record V1");

        String note = jdbc.queryForObject("SELECT note FROM spike_marker", String.class);
        assertEquals("created by Flyway V1, not by Hibernate", note,
            "ddl-auto is none, so if this row exists the migration is what built the schema");
    }

    @Test
    @DisplayName("Flowable created its own tables alongside, without interference")
    void flowableManagesItsOwnSchema() {
        Integer actTables = jdbc.queryForObject(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name LIKE 'ACT\\_%' ESCAPE '\\'",
                Integer.class);
        assertNotNull(actTables);
        assertTrue(actTables > 15,
            "Flowable should have created its own tables — found " + actTables);

        Integer deployed = jdbc.queryForObject(
                "SELECT COUNT(*) FROM ACT_RE_PROCDEF", Integer.class);
        assertNotNull(deployed);
        assertTrue(deployed >= 2, "both spike processes should be deployed");
    }

    @Test
    @DisplayName("the entity works against the Flyway-created table")
    void entityMatchesTheMigration() {
        repo.save(new AttemptRecord("TKT-FLYWAY", "TRANSPORT_CREDIT"));
        assertTrue(repo.existsByIdempotencyKey("TKT-FLYWAY:TRANSPORT_CREDIT"),
            "if the column names or types drifted from the entity, this fails");
    }
}
