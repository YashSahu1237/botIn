package in.yesmadam.botin.spike;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.togglz.core.manager.FeatureManager;
import org.togglz.core.repository.FeatureState;
import org.togglz.core.util.NamedFeature;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 4a — the kill switch.
 *
 * Two questions, one of them uncomfortable:
 *   1. Does flipping a flag change behaviour on the NEXT call, with no restart?
 *   2. What happens when a flag is resolved from a runtime STRING that does not
 *      match any enum constant? The real design does exactly this, because the
 *      flag name comes from concern_catalogue.togglz_flag.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:togglzspike;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class TogglzKillSwitchTest {

    @Autowired FeatureManager featureManager;

    @Test
    @DisplayName("a flag flipped at runtime takes effect on the next call, with no restart")
    void flagFlipTakesEffectImmediately() {
        featureManager.setFeatureState(new FeatureState(BotinFeature.TRANSPORT_AUTO_CREDIT, false));
        assertFalse(featureManager.isActive(BotinFeature.TRANSPORT_AUTO_CREDIT),
            "automation should be off");

        featureManager.setFeatureState(new FeatureState(BotinFeature.TRANSPORT_AUTO_CREDIT, true));
        assertTrue(featureManager.isActive(BotinFeature.TRANSPORT_AUTO_CREDIT),
            "THE POINT: no restart, no redeploy — the very next read sees the new state");

        featureManager.setFeatureState(new FeatureState(BotinFeature.TRANSPORT_AUTO_CREDIT, false));
        assertFalse(featureManager.isActive(BotinFeature.TRANSPORT_AUTO_CREDIT),
            "and back off again just as fast");
    }

    @Test
    @DisplayName("a flag can be resolved from a runtime string, the way the catalogue will")
    void flagResolvesFromARuntimeString() {
        featureManager.setFeatureState(new FeatureState(BotinFeature.TRANSPORT_AUTO_CREDIT, true));

        // This is what concern_catalogue.togglz_flag gives us: a String, not an enum.
        boolean active = featureManager.isActive(new NamedFeature("TRANSPORT_AUTO_CREDIT"));

        assertTrue(active, "resolving by name must agree with resolving by enum constant");
    }

    @Test
    @DisplayName("THE HOLE: a misspelt flag name resolves silently to false")
    void unknownFlagNameFailsSilently() {
        boolean active = featureManager.isActive(new NamedFeature("TRANSPROT_AUTO_CREDIT")); // typo on purpose

        assertFalse(active,
            "An unknown flag name does not throw — it just reads as 'off'. With fail-to-human "
          + "semantics that means a typo in concern_catalogue silently sends an entire concern "
          + "to agents, with no error anywhere. THIS is why ADR-007 requires startup validation "
          + "that every togglz_flag in the catalogue maps to a declared feature.");
    }
}
