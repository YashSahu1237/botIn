package in.yesmadam.botin.spike;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 4b — "degrade to a human, never break".
 *
 * The design claims a dead Python service routes the partner to an agent rather
 * than surfacing an error. This checks that the claim survives contact with the
 * actual library — including the part people forget: once the circuit is OPEN the
 * call stops being attempted at all, so the timeout is no longer paid per request.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:cbspike;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class CircuitBreakerDegradationTest {

    @Autowired FlakyClassifier classifier;
    @Autowired CircuitBreakerRegistry registry;

    @Test
    @DisplayName("a dead classifier degrades to T3 and then stops being called at all")
    void deadDependencyDegradesToAgent() {
        CircuitBreaker cb = registry.circuitBreaker("classifier");
        cb.reset();

        assertEquals(CircuitBreaker.State.CLOSED, cb.getState(), "starts closed");

        // Window is 4 calls; every one fails.
        for (int i = 0; i < 4; i++) {
            assertEquals("T3", classifier.classify("mera fine galat laga hai"),
                "the caller must never see the exception — it sees a tier");
        }

        assertEquals(CircuitBreaker.State.OPEN, cb.getState(),
            "after the window fills with failures the circuit must open");

        // Now the interesting part: the method body is not executed any more.
        long before = cb.getMetrics().getNumberOfFailedCalls();
        assertEquals("T3", classifier.classify("aur ek baar"),
            "still degrades cleanly while open");
        assertEquals(before, cb.getMetrics().getNumberOfFailedCalls(),
            "THE POINT: while OPEN the call is short-circuited, not attempted. "
          + "A struggling dependency stops costing a timeout on every request.");
    }
}
