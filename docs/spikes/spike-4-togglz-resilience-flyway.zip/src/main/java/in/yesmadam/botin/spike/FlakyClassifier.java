package in.yesmadam.botin.spike;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * SPIKE 4b — degradation.
 *
 * Stands in for ClassifierClient calling the Python service. It always fails.
 * The question is whether the caller waits, or gives up fast and routes to a human.
 */
@Service
public class FlakyClassifier {

    private static final Logger log = LoggerFactory.getLogger(FlakyClassifier.class);

    @CircuitBreaker(name = "classifier", fallbackMethod = "degradeToAgent")
    public String classify(String freeText) {
        throw new IllegalStateException("classifier unreachable");
    }

    /** Same signature plus a Throwable. Must be public and must not throw. */
    public String degradeToAgent(String freeText, Throwable cause) {
        log.info("classifier unavailable ({}) - degrading to T3", cause.getClass().getSimpleName());
        return "T3";
    }
}
