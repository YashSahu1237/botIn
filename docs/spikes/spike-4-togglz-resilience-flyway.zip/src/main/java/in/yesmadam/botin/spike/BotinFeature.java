package in.yesmadam.botin.spike;

import org.togglz.core.Feature;
import org.togglz.core.annotation.Label;

/**
 * SPIKE 4a — the kill switch.
 *
 * Togglz is enum-based. The real design needs to resolve a flag from a STRING
 * held in concern_catalogue.togglz_flag, which is the tension ADR-007 records.
 * Both routes are exercised in the test.
 */
public enum BotinFeature implements Feature {

    @Label("Transport auto-credit")
    TRANSPORT_AUTO_CREDIT;
}
