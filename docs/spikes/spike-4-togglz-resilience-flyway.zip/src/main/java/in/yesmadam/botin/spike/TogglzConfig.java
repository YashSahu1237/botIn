package in.yesmadam.botin.spike;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.togglz.core.repository.StateRepository;
import org.togglz.core.repository.jdbc.JDBCStateRepository;

import javax.sql.DataSource;

@Configuration
public class TogglzConfig {

    /**
     * Flag state lives in the application database, so a flip survives a restart
     * and is visible to every pod. NOTE what this table does NOT store: who flipped
     * a flag, or when. That gap is why ADR-007 requires flip auditing before Wave 1.
     */
    @Bean
    public StateRepository stateRepository(DataSource dataSource) {
        return new JDBCStateRepository(dataSource);
    }
}
