# Spike 4 — kill switch, degradation, and schema ownership

Drop into the existing `spike` project and re-run. **9 tests becomes 16.**

```bash
cd ~/Downloads/spike
unzip -o ~/Downloads/botin-spike-4.zip
mvn test
```

This overwrites `pom.xml` and `application.yml` — both are the originals plus additions,
nothing from spikes 1–3 is removed.

## 4a — Togglz, the kill switch

Two things work as the design assumes, and **one does not**.

Flipping a flag changes behaviour on the very next call, no restart. Resolving a flag
from a runtime *string* — which is what `concern_catalogue.togglz_flag` will hand us —
agrees with resolving it from the enum constant.

Then `unknownFlagNameFailsSilently` deliberately misspells a flag name. It does not
throw. It reads as **off**. With fail-to-human semantics that means one typo in the
catalogue quietly routes an entire concern to agents, with no error anywhere and
nothing in the logs. That is the concrete reason ADR-007 requires startup validation
that every `togglz_flag` in the catalogue maps to a declared feature.

If that test *fails* because Togglz threw an exception instead — tell me. That is a
better outcome than the design assumed, and the note should be softened.

Also worth noticing: `JDBCStateRepository` stores current state and nothing else.
**Not who flipped a flag, not when.** Look at the table in the H2 console. That gap
is D-7.

## 4b — Resilience4j, "degrade to a human, never break"

Four failing calls fill the window and the circuit opens. Every call returns `T3`,
never an exception — the caller sees a tier, not a stack trace.

The assertion people forget is the last one: once the circuit is **OPEN the method
body is not executed at all**. The failure count stops rising. A struggling Python
service therefore stops costing a timeout on every single request, which is the
difference between degraded and unusable under load.

## 4c — Flyway and Flowable, sharing one database

This is the one that could have been genuinely awkward. Flyway owns our tables;
Flowable creates its own ~25 `ACT_*` tables through its own mechanism and knows
nothing about Flyway.

`ddl-auto` is set to **none** in that test on purpose. If Hibernate were allowed to
create tables, the test would pass without Flyway doing anything, and prove nothing.
The `spike_marker` row exists only if the migration actually ran.

## After this

Only the FastAPI spike is left, and that is a separate Python project rather than
another file in here. Then write the page — one page per component, what it does,
how it is wired, what surprised you — and delete this folder.

The page is the deliverable. The code was only ever the way of asking.
