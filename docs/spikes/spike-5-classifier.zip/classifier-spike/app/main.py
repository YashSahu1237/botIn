"""
SPIKE 5 — the classifier service.

Two endpoints and nothing else. No database credentials, no action capability.
That is not tidiness: it is the containment ADR-003 relies on. This service can
return a wrong answer; it cannot reach a wallet.
"""
import logging

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.model_client import StubModel
from app.schemas import (
    ClassifyRequest, ClassifyResponse,
    IntentRequest, IntentResponse,
    ContractViolation,
)

log = logging.getLogger("classifier")
app = FastAPI(title="BOTIn classifier (spike)", version="0.1.0")
model = StubModel()

# 502, not 500: the fault is upstream of us. Java's ClassifierClient treats any
# non-2xx identically — set tier = T3 and carry on — so the partner still gets
# served by a human. Nothing downstream ever sees a half-valid category.
CONTRACT_VIOLATION_STATUS = 502


def _violation(detail: str, raw: object) -> JSONResponse:
    log.warning("classifier contract violation: %s | raw=%r", detail, raw)
    body = ContractViolation(detail=detail, raw=str(raw)[:500])
    return JSONResponse(status_code=CONTRACT_VIOLATION_STATUS, content=body.model_dump())


@app.get("/health")
def health():
    return {"status": "ok", "model": "stub"}


@app.post("/classify", response_model=ClassifyResponse)
def classify(req: ClassifyRequest):
    """Concern already known. Extract a reason from within that concern's fixed set."""
    raw = model.classify_reason(req.free_text)

    if not isinstance(raw, dict):
        return _violation("model did not return an object", raw)
    try:
        return ClassifyResponse(**raw)
    except ValidationError as e:
        return _violation(e.errors()[0]["msg"] if e.errors() else str(e), raw)


@app.post("/classify-intent", response_model=IntentResponse)
def classify_intent(req: IntentRequest):
    """No concern yet. Match raw text against the whole taxonomy."""
    raw = model.classify_intent(req.free_text)

    if not isinstance(raw, dict):
        return _violation("model did not return an object", raw)
    try:
        return IntentResponse(**raw)
    except ValidationError as e:
        return _violation(e.errors()[0]["msg"] if e.errors() else str(e), raw)
