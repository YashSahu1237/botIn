"""
SPIKE 5 — the contract between Python and Java.

Everything in this file exists to answer one question: when the model returns
something wrong, does it stop HERE, or does it reach a decision table that moves
money?

The design claims (ADR-003) that the classifier "can misclassify but cannot
wrongly credit a wallet". That claim is only true if the set of values it can
return is genuinely closed. A hallucinated category that happens to match a DMN
rule, or a confidence of 1.7 sailing past a `>= 0.7` threshold, would break it.
"""
from enum import Enum
from pydantic import BaseModel, Field, field_validator


class L2Concern(str, Enum):
    """The closed set /classify-intent may return. The eight POC concerns, plus UNKNOWN."""
    TRANSPORT_NOT_RECEIVED   = "TRANSPORT_NOT_RECEIVED"
    RECHARGE_DEBIT_NO_CREDIT = "RECHARGE_DEBIT_NO_CREDIT"
    FORGET_MPIN              = "FORGET_MPIN"
    PROD_DELIVERY_DELAY      = "PROD_DELIVERY_DELAY"
    VIOL_R5_PERIODS          = "VIOL_R5_PERIODS"
    VIOL_R4_OTHERS           = "VIOL_R4_OTHERS"
    VIOL_R9_NO_PRODUCT       = "VIOL_R9_NO_PRODUCT"
    OTHER_FREETEXT_TRIAGE    = "OTHER_FREETEXT_TRIAGE"
    UNKNOWN                  = "UNKNOWN"


class ViolationReason(str, Enum):
    """The closed set /classify may return inside VIOL_R4_OTHERS."""
    R1_FAR_JOB        = "R1_FAR_JOB"
    R3_DELAYED_PREV   = "R3_DELAYED_PREV"
    R7_SMALL_BOOKING  = "R7_SMALL_BOOKING"
    R8_HEALTH         = "R8_HEALTH"
    R9_NO_PRODUCT     = "R9_NO_PRODUCT"
    R10_EMERGENCY     = "R10_EMERGENCY"
    OTHER             = "OTHER"


class Language(str, Enum):
    HI       = "hi"
    EN       = "en"
    HINGLISH = "hinglish"


class ClassifyRequest(BaseModel):
    ticket_id: str = Field(min_length=1, max_length=64)
    l2_concern: L2Concern
    free_text: str = Field(min_length=1, max_length=2000)


class ClassifyResponse(BaseModel):
    category: ViolationReason
    confidence_score: float = Field(ge=0.0, le=1.0)
    extracted_reason: str = Field(max_length=280)
    detected_language: Language

    @field_validator("category", mode="before")
    @classmethod
    def tolerate_formatting_not_membership(cls, v):
        """
        Liberal about FORMATTING, strict about MEMBERSHIP.

        Models return " r9_no_product " often enough that rejecting it would be
        pedantry. Returning "refund_immediately" is a different thing entirely and
        must fail — so normalise whitespace and case, then let the enum decide.
        """
        return v.strip().upper() if isinstance(v, str) else v


class IntentRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=64)
    free_text: str = Field(min_length=1, max_length=2000)


class IntentResponse(BaseModel):
    l2_concern: L2Concern
    confidence_score: float = Field(ge=0.0, le=1.0)
    detected_language: Language

    @field_validator("l2_concern", mode="before")
    @classmethod
    def tolerate_formatting_not_membership(cls, v):
        return v.strip().upper() if isinstance(v, str) else v


class ContractViolation(BaseModel):
    """
    What Java receives when the model broke the contract.

    Deliberately NOT shaped like a classification result: there is no category and
    no confidence, so nothing downstream can mistake it for one.
    """
    error: str = "classifier_contract_violation"
    detail: str
    raw: str | None = None
