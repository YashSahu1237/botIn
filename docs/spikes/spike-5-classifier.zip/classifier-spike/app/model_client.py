"""
The stub standing in for the LLM, until a key exists.

It is keyed on fixture text so every path is deterministic, and it can be told to
misbehave in the specific ways a real model does. Those __bad_* fixtures are the
entire point of the spike — a stub that only ever returns valid output would prove
nothing about the boundary.
"""
from typing import Any

_INTENT_FIXTURES: dict[str, dict[str, Any]] = {
    "transport amount nahi mila":
        {"l2_concern": "TRANSPORT_NOT_RECEIVED", "confidence_score": 0.94, "detected_language": "hinglish"},
    "recharge kiya, pese cut gaye par wallet me nahi aaye":
        {"l2_concern": "RECHARGE_DEBIT_NO_CREDIT", "confidence_score": 0.91, "detected_language": "hinglish"},
    "mpin bhool gaya hoon":
        {"l2_concern": "FORGET_MPIN", "confidence_score": 0.96, "detected_language": "hinglish"},
    "product abhi tak deliver nahi hua":
        {"l2_concern": "PROD_DELIVERY_DELAY", "confidence_score": 0.88, "detected_language": "hinglish"},
    "kuch samajh nahi aa raha":
        {"l2_concern": "UNKNOWN", "confidence_score": 0.31, "detected_language": "hinglish"},
    # formatting noise a real model produces constantly — must be tolerated
    "  transport ka paisa nahi aaya  ":
        {"l2_concern": " transport_not_received ", "confidence_score": 0.9, "detected_language": "hinglish"},
}

_REASON_FIXTURES: dict[str, dict[str, Any]] = {
    "job bahut door thi":
        {"category": "R1_FAR_JOB", "confidence_score": 0.92,
         "extracted_reason": "job was too far", "detected_language": "hinglish"},
    "pichli job late ho gayi thi":
        {"category": "R3_DELAYED_PREV", "confidence_score": 0.87,
         "extracted_reason": "previous job overran", "detected_language": "hinglish"},
    "product nahi tha mere paas":
        {"category": "R9_NO_PRODUCT", "confidence_score": 0.9,
         "extracted_reason": "did not have the product", "detected_language": "hinglish"},
    "tabiyat kharab thi":
        {"category": "R8_HEALTH", "confidence_score": 0.93,
         "extracted_reason": "health issue", "detected_language": "hinglish"},

    # ---- deliberate contract violations ----
    "__hallucinated_category__":
        {"category": "refund_immediately", "confidence_score": 0.99,
         "extracted_reason": "model invented an action", "detected_language": "en"},
    "__confidence_out_of_range__":
        {"category": "R8_HEALTH", "confidence_score": 1.7,
         "extracted_reason": "over-confident", "detected_language": "en"},
    "__missing_field__":
        {"category": "R8_HEALTH", "extracted_reason": "no confidence at all", "detected_language": "en"},
    "__unknown_language__":
        {"category": "R8_HEALTH", "confidence_score": 0.8,
         "extracted_reason": "language not in our set", "detected_language": "mr"},
}


class StubModel:
    """Swap this for a vendor client and nothing above it changes."""

    def classify_reason(self, free_text: str) -> Any:
        key = free_text.strip().lower()
        if key == "__prose__":
            # A real model ignoring "reply with JSON" and writing a sentence.
            return "Sure! It sounds like the partner had a health issue that day."
        if key in _REASON_FIXTURES:
            return dict(_REASON_FIXTURES[key])
        return {"category": "OTHER", "confidence_score": 0.28,
                "extracted_reason": free_text[:280], "detected_language": "hinglish"}

    def classify_intent(self, free_text: str) -> Any:
        key = free_text.lower()
        if key.strip() in (k.strip() for k in _INTENT_FIXTURES):
            for k, v in _INTENT_FIXTURES.items():
                if k.strip() == key.strip():
                    return dict(v)
        return {"l2_concern": "UNKNOWN", "confidence_score": 0.22, "detected_language": "hinglish"}
