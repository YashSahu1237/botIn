# Spike 5 — the classifier boundary

A separate Python project, not part of the Java spike. Two endpoints, no database
credentials, no ability to take an action.

```bash
cd classifier-spike
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pytest -q                      # expect: 12 passed
```

**Already verified.** Unlike the Java spikes, this one was built and run before you
received it — 12 tests pass, and every endpoint was exercised against a live server.

## Why this spike is needed

The Python service does one narrow job: turn free text into **one value from a fixed
list**. It is the only non-Java deployable, and the only place a contract crosses a
language boundary. Three reasons it gets its own spike.

**1. The safety claim is unproven until you try to break it.** ADR-003 says the
classifier "can misclassify but cannot wrongly credit a wallet" — misclassification
is bounded because a wrong category either matches no rule or routes to a human.
That holds **only if the set of returnable values is genuinely closed.** A model that
returns `refund_immediately`, or a confidence of `1.7`, breaks it: `1.7` sails past
every `>= 0.7` threshold in every decision table you will ever write. The spike
proves the boundary is real rather than assumed.

**2. Models fail in specific, repeatable ways.** They hallucinate values outside the
set, drop fields, put numbers out of range, and ignore "reply with JSON" to write a
sentence instead. Each of those is a fixture here. Building the service without
having watched it reject them is building on hope.

**3. It de-risks the vendor swap.** No LLM is chosen yet. If the boundary holds, the
vendor behind it is an implementation detail and swapping one for another is
contained. If it does not, every vendor change is a fresh risk to the money path.

## What it proves

| Behaviour | Result |
|---|---|
| Valid text classifies into the closed set | 200 with a typed result |
| A confident *"I don't know"* | **200**, low confidence — that is a valid answer, and Java's threshold decides |
| ` transport_not_received ` with stray spaces and case | **200** — formatting noise is normalised |
| `refund_immediately` — a category nobody defined | **502** |
| `confidence_score: 1.7` | **502** |
| A missing field | **502** |
| Prose instead of JSON | **502** |
| A language outside our set | **502** |
| Java sends an `l2_concern` outside the taxonomy | **422** — the boundary runs both ways |

**Liberal about formatting, strict about membership.** Trimming `" r9_no_product "`
is courtesy; accepting `"refund_immediately"` is a money bug. The distinction is one
validator in `schemas.py` and it is the most opinionated line in the service.

**A rejection is structurally unlike a result.** `ContractViolation` carries no
`category` and no `confidence_score`, so nothing downstream can mistake one for the
other — there is a test asserting exactly that. **502, not 500**: the fault is
upstream of us, and Java's `ClassifierClient` treats any non-2xx the same way — set
`tier = T3` and carry on. The partner still gets served, by a human.

## Swapping the stub for a real model

`model_client.py` is the only file that changes. `StubModel.classify_reason()` and
`.classify_intent()` return a dict; a vendor client returns a dict. Everything
above — validation, error shaping, status codes, the Java contract — is untouched.

The `__bad_*` fixtures stay. They are how you find out that a *new* vendor breaks
the contract in a way the old one did not.

## What it does NOT prove

**Accuracy.** There is no real ticket text and no model, so U-2 stays unanswered.
The fixtures were written by the same person who wrote the classifier, which
guarantees they classify well and proves nothing. **Report U-2 as *not assessed*,
never as passed.**

## Run it by hand

```bash
uvicorn app.main:app --reload --port 8000

curl localhost:8000/health

curl -XPOST localhost:8000/classify-intent -H 'Content-Type: application/json' \
  -d '{"session_id":"S-1","free_text":"transport amount nahi mila"}'

curl -i -XPOST localhost:8000/classify -H 'Content-Type: application/json' \
  -d '{"ticket_id":"TKT-1","l2_concern":"VIOL_R4_OTHERS","free_text":"__hallucinated_category__"}'
```

Interactive docs at http://localhost:8000/docs — that page is the contract Java
codes against.
