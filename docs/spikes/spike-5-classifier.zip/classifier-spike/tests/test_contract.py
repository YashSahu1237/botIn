"""
SPIKE 5 — does a bad model response stop at the boundary?

The valid cases are the boring half. The four __bad_* cases are why this exists.
"""
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def _classify(free_text: str):
    return client.post("/classify", json={
        "ticket_id": "TKT-1", "l2_concern": "VIOL_R4_OTHERS", "free_text": free_text})


def _intent(free_text: str):
    return client.post("/classify-intent", json={"session_id": "S-1", "free_text": free_text})


# ----------------------------------------------------------------- it works

def test_health():
    assert client.get("/health").json()["status"] == "ok"


def test_valid_reason_classifies():
    r = _classify("job bahut door thi")
    assert r.status_code == 200
    assert r.json()["category"] == "R1_FAR_JOB"
    assert 0.0 <= r.json()["confidence_score"] <= 1.0


def test_valid_intent_classifies():
    r = _intent("transport amount nahi mila")
    assert r.status_code == 200
    assert r.json()["l2_concern"] == "TRANSPORT_NOT_RECEIVED"


def test_low_confidence_is_returned_not_rejected():
    """A confident 'I don't know' is a VALID answer. Java's threshold decides, not us."""
    r = _intent("kuch samajh nahi aa raha")
    assert r.status_code == 200
    assert r.json()["l2_concern"] == "UNKNOWN"
    assert r.json()["confidence_score"] < 0.7


def test_formatting_noise_is_tolerated():
    """' transport_not_received ' is sloppiness, not a contract breach. Normalise it."""
    r = _intent("  transport ka paisa nahi aaya  ")
    assert r.status_code == 200
    assert r.json()["l2_concern"] == "TRANSPORT_NOT_RECEIVED"


# ------------------------------------------------- it fails in the right way

def test_hallucinated_category_is_rejected():
    """
    THE ONE THAT MATTERS. The model invents 'refund_immediately'. If that reached
    Java it would enter a DMN table as a category nobody wrote a rule for — or
    worse, one somebody did.
    """
    r = _classify("__hallucinated_category__")
    assert r.status_code == 502
    assert r.json()["error"] == "classifier_contract_violation"
    assert "category" not in r.json()
    assert "confidence_score" not in r.json()


def test_confidence_out_of_range_is_rejected():
    """1.7 would sail past every '>= 0.7' rule in every decision table."""
    r = _classify("__confidence_out_of_range__")
    assert r.status_code == 502
    assert "confidence_score" not in r.json()


def test_missing_field_is_rejected():
    r = _classify("__missing_field__")
    assert r.status_code == 502


def test_prose_instead_of_json_is_rejected():
    """The model ignores 'reply with JSON' and writes a sentence."""
    r = _classify("__prose__")
    assert r.status_code == 502
    assert "did not return an object" in r.json()["detail"]


def test_unknown_language_is_rejected():
    r = _classify("__unknown_language__")
    assert r.status_code == 502


def test_violation_is_never_mistakable_for_a_result():
    """
    Every rejection must be structurally unlike a classification. If it carried a
    category field at all, some future caller would read it.
    """
    for fixture in ("__hallucinated_category__", "__confidence_out_of_range__",
                    "__missing_field__", "__prose__", "__unknown_language__"):
        body = _classify(fixture).json()
        assert set(body.keys()) <= {"error", "detail", "raw"}


def test_bad_request_from_java_is_rejected_too():
    """The boundary runs both ways: an l2_concern outside the taxonomy is a 422."""
    r = client.post("/classify", json={
        "ticket_id": "TKT-1", "l2_concern": "NOT_A_REAL_CONCERN", "free_text": "x"})
    assert r.status_code == 422
