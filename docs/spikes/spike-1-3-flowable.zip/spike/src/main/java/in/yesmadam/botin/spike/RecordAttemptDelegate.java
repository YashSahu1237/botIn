package in.yesmadam.botin.spike;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("recordAttemptDelegate")
public class RecordAttemptDelegate implements JavaDelegate {

    private final AttemptRecorder recorder;

    public RecordAttemptDelegate(AttemptRecorder recorder) { this.recorder = recorder; }

    @Override
    public void execute(DelegateExecution execution) {
        String ticketId   = (String) execution.getVariable("ticketId");
        String actionType = (String) execution.getVariable("actionType");
        boolean ownTx = Boolean.TRUE.equals(execution.getVariable("useRequiresNew"));

        if (ownTx) {
            recorder.recordInOwnTransaction(ticketId, actionType);
        } else {
            recorder.recordJoiningCallerTransaction(ticketId, actionType);
        }
        // In the real design the external call happens HERE — after the commit above,
        // never before it.
    }
}
