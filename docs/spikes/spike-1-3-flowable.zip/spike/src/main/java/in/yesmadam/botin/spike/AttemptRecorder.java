package in.yesmadam.botin.spike;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * The whole of spike 3 is the difference between these two methods.
 *
 * A Flowable Service Task runs inside the engine's transaction. If a LATER node
 * throws, the engine rolls back — and by default that takes our record with it,
 * while the external system it describes does not roll back. Money moved, no evidence.
 *
 * TRAP: these must be called from ANOTHER bean. Spring's proxy is what applies the
 * annotation, so a call from inside this class to itself silently ignores it. The
 * delegate calling this service is a real external call, which is why it works.
 */
@Service
public class AttemptRecorder {

    private static final Logger log = LoggerFactory.getLogger(AttemptRecorder.class);
    private final AttemptRecordRepository repo;

    public AttemptRecorder(AttemptRecordRepository repo) { this.repo = repo; }

    /** Suspends the engine's transaction, opens its own, commits, returns. Survives a rollback. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AttemptRecord recordInOwnTransaction(String ticketId, String actionType) {
        AttemptRecord saved = repo.saveAndFlush(new AttemptRecord(ticketId, actionType));
        log.info("recorded in OWN transaction id={} key={}", saved.getId(), saved.getIdempotencyKey());
        return saved;
    }

    /** Default propagation: joins the engine's transaction. Dies with it. This is the bug. */
    @Transactional
    public AttemptRecord recordJoiningCallerTransaction(String ticketId, String actionType) {
        AttemptRecord saved = repo.saveAndFlush(new AttemptRecord(ticketId, actionType));
        log.info("recorded in CALLER's transaction id={} key={}", saved.getId(), saved.getIdempotencyKey());
        return saved;
    }
}
