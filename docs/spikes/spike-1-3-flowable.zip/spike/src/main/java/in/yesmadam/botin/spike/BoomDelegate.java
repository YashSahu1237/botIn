package in.yesmadam.botin.spike;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/** Stands in for any later node failing after the money already moved. */
@Component("boomDelegate")
public class BoomDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        throw new IllegalStateException("deliberate failure after the external call");
    }
}
