package in.yesmadam.botin.spike;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AttemptRecordRepository extends JpaRepository<AttemptRecord, Long> {
    boolean existsByIdempotencyKey(String idempotencyKey);
}
