package in.yesmadam.botin.spike;

import jakarta.persistence.*;
import java.time.Instant;

/** Stand-in for ticket_action. The only thing that matters is whether it survives. */
@Entity
@Table(name = "attempt_record",
       uniqueConstraints = @UniqueConstraint(columnNames = "idempotency_key"))
public class AttemptRecord {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String ticketId;
    @Column(nullable = false) private String actionType;
    @Column(name = "idempotency_key", nullable = false) private String idempotencyKey;
    @Column(nullable = false) private String status;
    @Column(nullable = false) private Instant createdAt = Instant.now();

    protected AttemptRecord() { }

    public AttemptRecord(String ticketId, String actionType) {
        this.ticketId = ticketId;
        this.actionType = actionType;
        this.idempotencyKey = ticketId + ":" + actionType;   // hash(ticketId, actionType)
        this.status = "ATTEMPTED";
    }

    public Long getId() { return id; }
    public String getTicketId() { return ticketId; }
    public String getActionType() { return actionType; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
}
