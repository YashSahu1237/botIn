package in.yesmadam.botin.spike;

import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.task.api.Task;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Exists so you can do the HONEST version of spike 1: start a process, kill -9 the
 * JVM, start it again, and find the task still waiting. A test that restarts a
 * Spring context proves the state is in the database; killing the process proves it
 * to a room.
 */
@RestController
@RequestMapping("/spike")
public class SpikeController {

    private final RuntimeService runtimeService;
    private final TaskService taskService;
    private final HistoryService historyService;

    public SpikeController(RuntimeService runtimeService, TaskService taskService, HistoryService historyService) {
        this.runtimeService = runtimeService;
        this.taskService = taskService;
        this.historyService = historyService;
    }

    @PostMapping("/start")
    public Map<String, Object> start() {
        String pid = runtimeService.startProcessInstanceByKey("spike-restart").getId();
        return Map.of("processInstanceId", pid, "osPid", ProcessHandle.current().pid());
    }

    @GetMapping("/tasks")
    public List<Map<String, String>> tasks() {
        return taskService.createTaskQuery().taskCandidateGroup("agent-queue").list()
                .stream()
                .map(t -> Map.of("taskId", t.getId(), "name", t.getName(),
                                 "processInstanceId", t.getProcessInstanceId(),
                                 "created", String.valueOf(t.getCreateTime())))
                .toList();
    }

    @PostMapping("/tasks/{taskId}/complete")
    public Map<String, Object> complete(@PathVariable String taskId) {
        Task t = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (t == null) return Map.of("error", "no such task", "taskId", taskId);
        String pid = t.getProcessInstanceId();
        taskService.complete(taskId);
        return Map.of("completed", taskId, "processInstanceId", pid);
    }

    @GetMapping("/status/{processInstanceId}")
    public Map<String, Object> status(@PathVariable String processInstanceId) {
        HistoricProcessInstance h = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstanceId).singleResult();
        if (h == null) return Map.of("found", false);
        return Map.of("found", true,
                      "startTime", String.valueOf(h.getStartTime()),
                      "endTime", String.valueOf(h.getEndTime()),
                      "finished", h.getEndTime() != null,
                      "osPid", ProcessHandle.current().pid());
    }
}
