package in.yesmadam.botin.spike;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * A JavaDelegate is just a Spring bean with one method. The BPMN refers to it by
 * bean name through flowable:delegateExpression="${logDelegate}" — that string and
 * the @Component name are the entire wiring. There is no registration step.
 */
@Component("logDelegate")
public class LogDelegate implements JavaDelegate {

    private static final Logger log = LoggerFactory.getLogger(LogDelegate.class);

    @Override
    public void execute(DelegateExecution execution) {
        log.info("[{}] node={} processInstance={} pid(os)={}",
                execution.getProcessDefinitionId(),
                execution.getCurrentActivityId(),
                execution.getProcessInstanceId(),
                ProcessHandle.current().pid());
        execution.setVariable("lastNode", execution.getCurrentActivityId());
    }
}
