package in.yesmadam.botin.spike;

import org.flowable.engine.RuntimeService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 3 — the second go/no-go gate.
 *
 * Two tests, and the FAILING one matters more. A test that only proves the good
 * case cannot tell you whether it would catch the annotation being removed in six
 * months. Here, removing REQUIRES_NEW is simulated by a process variable, and the
 * second test asserts the record is lost — so the pair has teeth.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:requiresnew;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class RequiresNewTest {

    @Autowired RuntimeService runtimeService;
    @Autowired AttemptRecordRepository repo;

    @BeforeEach
    void clear() { repo.deleteAll(); }

    @Test
    @DisplayName("REQUIRES_NEW: the attempt record survives the engine's rollback")
    void recordSurvivesRollback() {
        assertThrows(Exception.class, () -> runtimeService.startProcessInstanceByKey(
                "spike-money", Map.of(
                        "ticketId", "TKT-1",
                        "actionType", "TRANSPORT_CREDIT",
                        "useRequiresNew", true)));

        assertEquals(1, repo.count(),
            "THE GATE: the ATTEMPTED row must outlive the rollback — it is the only evidence "
          + "that an external system was called");
        assertTrue(repo.existsByIdempotencyKey("TKT-1:TRANSPORT_CREDIT"));
    }

    @Test
    @DisplayName("default propagation: the attempt record is lost with the rollback — this is the bug")
    void recordIsLostWithoutRequiresNew() {
        assertThrows(Exception.class, () -> runtimeService.startProcessInstanceByKey(
                "spike-money", Map.of(
                        "ticketId", "TKT-2",
                        "actionType", "TRANSPORT_CREDIT",
                        "useRequiresNew", false)));

        assertEquals(0, repo.count(),
            "joining the engine's transaction means the record dies with it. If this "
          + "assertion ever fails, the first test has stopped proving anything.");
    }
}
