package in.yesmadam.botin.spike;

import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.task.api.Task;
import org.junit.jupiter.api.*;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.IOException;
import java.nio.file.*;
import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 1 — the go/no-go gate.
 *
 * Deliberately NOT a @SpringBootTest. The point is to stand a context up, park a
 * process, tear the context down COMPLETELY — engine shut down, caches gone,
 * nothing in memory — and then start a fresh one that has never seen this process
 * instance. If the task is still there, process state lives in the database and
 * ADR-001 holds. If it isn't, stop and redesign.
 *
 * For the version that convinces a room, use the REST endpoints and kill -9 the JVM.
 * See README.
 */
class RestartSurvivalTest {

    private static final Path DB_DIR = Paths.get("./target/spike-restart-db");

    private static final String[] ARGS = {
        "--spring.main.web-application-type=none",
        "--spring.main.banner-mode=off",
        "--spring.datasource.url=jdbc:h2:file:./target/spike-restart-db/db;DB_CLOSE_ON_EXIT=FALSE",
        "--spring.h2.console.enabled=false"
    };

    @BeforeAll
    static void cleanDatabase() throws IOException {
        if (Files.exists(DB_DIR)) {
            try (var paths = Files.walk(DB_DIR)) {
                paths.sorted(Comparator.reverseOrder()).forEach(p -> {
                    try { Files.deleteIfExists(p); } catch (IOException ignored) { }
                });
            }
        }
        Files.createDirectories(DB_DIR);
    }

    @Test
    @DisplayName("a parked process instance survives full engine shutdown and resumes")
    void processSurvivesEngineShutdown() {
        String processInstanceId;
        String taskIdBefore;

        // ---------- lifetime 1 ----------
        try (ConfigurableApplicationContext ctx = SpringApplication.run(SpikeApplication.class, ARGS)) {
            RuntimeService runtime = ctx.getBean(RuntimeService.class);
            TaskService tasks = ctx.getBean(TaskService.class);

            processInstanceId = runtime.startProcessInstanceByKey("spike-restart").getId();

            Task parked = tasks.createTaskQuery().processInstanceId(processInstanceId).singleResult();
            assertNotNull(parked, "process should be parked on the user task");
            assertEquals("Wait for agent", parked.getName());
            taskIdBefore = parked.getId();

            assertNull(
                ctx.getBean(HistoryService.class).createHistoricProcessInstanceQuery()
                   .processInstanceId(processInstanceId).singleResult().getEndTime(),
                "process must not be finished yet");
        }
        // context closed: engine stopped, every cache discarded.

        // ---------- lifetime 2 ----------
        try (ConfigurableApplicationContext ctx = SpringApplication.run(SpikeApplication.class, ARGS)) {
            TaskService tasks = ctx.getBean(TaskService.class);

            Task resumed = tasks.createTaskQuery().processInstanceId(processInstanceId).singleResult();
            assertNotNull(resumed,
                "THE GATE: the task must still exist after the engine was shut down and restarted");
            assertEquals(taskIdBefore, resumed.getId(), "it must be the same task, not a new one");

            tasks.complete(resumed.getId());

            HistoricProcessInstance finished = ctx.getBean(HistoryService.class)
                    .createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();

            assertNotNull(finished.getEndTime(),
                "THE GATE: the process must run to completion after resuming in a new engine");
        }
    }
}
