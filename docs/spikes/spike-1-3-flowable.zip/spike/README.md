# BOTIn — Flowable spike

Throwaway. Two questions, both of which can invalidate the architecture, and neither of
which should be answered by reading documentation.

| | Question | Where |
|---|---|---|
| **Spike 1** | Does a parked process survive the JVM dying, and resume? | `RestartSurvivalTest` + the REST endpoints |
| **Spike 3** | Does `REQUIRES_NEW` protect the action record through an engine rollback? | `RequiresNewTest` |

If spike 1 fails, ADR-001 collapses — the whole reason for embedding a process engine is
this behaviour. If spike 3 fails, the money-safety model needs redesign. Either way, stop
and rethink before building anything on top.

---

## Run the tests

```bash
mvn test
```

Four assertions matter:

- the task still exists after a full engine shutdown, and it is **the same task**
- the process runs to completion after resuming in an engine that never saw it start
- the attempt record **survives** the rollback with `REQUIRES_NEW`
- the attempt record **is lost** without it

That last one is the important one. A test that only proves the good case cannot tell you
whether it would catch the annotation being deleted later. Here, removing it is simulated
by a process variable, so the pair has teeth.

---

## Run the honest version of spike 1

`RestartSurvivalTest` tears the Spring context down completely, which proves the state is
in the database. Killing the process proves it to a room.

```bash
mvn spring-boot:run
```

```bash
# 1. start a process — it parks on the user task
curl -s -XPOST localhost:8080/spike/start
# {"processInstanceId":"4","osPid":81234}

# 2. confirm it is waiting
curl -s localhost:8080/spike/tasks

# 3. KILL THE JVM. Not a graceful shutdown — kill it.
kill -9 81234

# 4. start it again
mvn spring-boot:run

# 5. the task is still there, created before the process you just killed
curl -s localhost:8080/spike/tasks

# 6. complete it and watch the process finish
curl -s -XPOST localhost:8080/spike/tasks/<taskId>/complete
curl -s localhost:8080/spike/status/<processInstanceId>
# "finished": true — and a different osPid from step 1
```

Look at the database yourself at http://localhost:8080/h2-console
(JDBC URL `jdbc:h2:file:./data/spikedb`). The row in `ACT_RU_TASK` is the entire mechanism.
`ACT_RU_*` is live state; `ACT_HI_*` is history. When a process completes, its `ACT_RU_*`
rows are **deleted** — which is exactly why the real design writes `nextStep` onto the
session row instead of reading process variables after completion.

---

## What to look at while it runs

- `spike-restart.bpmn20.xml` — five nodes. The `userTask` is the only one that matters.
- `LogDelegate` — a `JavaDelegate` is a Spring bean with one method. The BPMN finds it by
  bean name through `flowable:delegateExpression="${logDelegate}"`. That string and the
  `@Component` name are the entire wiring; there is no registration step.
- `AttemptRecorder` — two methods that differ only in propagation. That difference is the
  most load-bearing line in the production design.

---

## Traps this spike exists to teach

**Self-invocation silently disables `@Transactional`.** Spring applies it through a proxy,
so a call from inside `AttemptRecorder` to another of its own methods ignores the
annotation entirely — no error, no warning. The delegate calling the service from outside
is what makes it work. This is the single easiest way to reintroduce the bug later.

**File mode, not in-memory.** `application.yml` points H2 at a file on purpose. An
in-memory database would make spike 1 pass for the wrong reason.

**Async executor is off.** Nothing here is async and leaving it on adds background noise.
In production it must be on, and configured for multiple pods.

**H2 is not the answer, only the first answer.** Re-run both spikes on Postgres before
trusting them — `--spring.profiles.active=postgres`. H2 proves the behaviour; Postgres
proves it on the DDL you will ship.

**`history-level: audit`, not `full`.** Same setting as the real design, for the same
reason: bounded write volume.

---

## What this spike deliberately does not do

No DMN, no Togglz, no classifier, no catalogue, no real concern. Those are separate
spikes and separate questions. This one answers two, and then gets deleted.

Write a page on what you learned before deleting it. That page is the seed of the
production runbook, and it is the actual deliverable here — not the code.
