package in.yesmadam.botin.spike;

import org.flowable.dmn.api.DmnDecisionService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SPIKE 2 — the decision engine.
 *
 * Not a go/no-go gate like spikes 1 and 3. This one exists to make two claims from
 * the design concrete, because both are easy to get wrong once someone starts
 * editing tables:
 *
 *   1. Under hit policy FIRST, ROW ORDER IS LOGIC, not formatting.
 *   2. A table without a terminal catch-all returns NOTHING when nothing matches.
 *
 * Three .dmn files, identical except for row order and one missing row.
 * The DMN engine ships in the same flowable-spring-boot-starter as the process
 * engine — if this test runs at all, that claim from ADR-002 is also confirmed.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:dmnspike;DB_CLOSE_DELAY=-1",
    "spring.jpa.hibernate.ddl-auto=create-drop"
})
class DmnHitPolicyTest {

    @Autowired DmnDecisionService dmnDecisionService;

    private static Map<String, Object> facts(String category, double confidence, int claimFreq30d) {
        Map<String, Object> f = new HashMap<>();
        f.put("category", category);
        f.put("confidence", confidence);
        f.put("claimFreq30d", claimFreq30d);
        return f;
    }

    /** Returns null when no row matches — which is the point of the last test. */
    private Map<String, Object> decide(String decisionKey, Map<String, Object> facts) {
        return dmnDecisionService.createExecuteDecisionBuilder()
                .decisionKey(decisionKey)
                .variables(facts)
                .executeWithSingleResult();
    }

    // ---------------------------------------------------------------- basics

    @Test
    @DisplayName("a genuine claim with a low claim rate is auto-waived")
    void genuineClaimIsAutoWaived() {
        Map<String, Object> r = decide("spike-decision", facts("health_issue", 0.9, 1));
        assertNotNull(r);
        assertEquals("T2", r.get("tier"));
        assertEquals("auto_waive", r.get("action"));
    }

    @Test
    @DisplayName("the same claim at a high claim rate goes to an agent instead")
    void highClaimRateEscalates() {
        Map<String, Object> r = decide("spike-decision", facts("health_issue", 0.9, 5));
        assertEquals("T3", r.get("tier"));
        assertEquals("route_agent_high_claim_rate", r.get("action"));
    }

    // ------------------------------------------------------- FIRST hit policy

    @Test
    @DisplayName("FIRST: when two rows match, the topmost one wins")
    void topmostMatchingRowWins() {
        // confidence 0.5 matches row 1 AND the catch-all in row 4.
        // Both return tier T3, so only the ACTION reveals which row actually fired.
        Map<String, Object> r = decide("spike-decision", facts("health_issue", 0.5, 1));

        assertEquals("route_agent_low_confidence", r.get("action"),
            "row 1 must win — if this says route_agent_catchall, FIRST is not behaving as assumed");
    }

    @Test
    @DisplayName("a category no rule mentions falls through to the catch-all")
    void unmatchedCategoryHitsTheCatchAll() {
        Map<String, Object> r = decide("spike-decision", facts("personal_reasons", 0.9, 1));
        assertEquals("route_agent_catchall", r.get("action"));
    }

    // ------------------------------------------------- the two lessons

    @Test
    @DisplayName("ROW ORDER IS LOGIC: the same four rules, reordered, give a different answer")
    void rowOrderChangesTheAnswer() {
        Map<String, Object> input = facts("health_issue", 0.9, 1);

        Map<String, Object> correct    = decide("spike-decision", input);
        Map<String, Object> misordered = decide("spike-decision-misordered", input);

        assertEquals("auto_waive", correct.get("action"));
        assertEquals("route_agent_catchall", misordered.get("action"));

        assertNotEquals(correct.get("tier"), misordered.get("tier"),
            "identical rules, identical facts, one row moved — and the partner's money "
          + "moves in one case and not the other. This is why a table edit needs review.");
    }

    @Test
    @DisplayName("NO CATCH-ALL: an unmatched case returns nothing at all")
    void missingCatchAllReturnsNothing() {
        Map<String, Object> r = decide("spike-decision-nocatchall", facts("personal_reasons", 0.9, 1));

        assertNull(r,
            "no row matched and there is no default, so the engine returns nothing. "
          + "In a real process the gateway reading ${tier} then has no branch to take. "
          + "Thirteen of the 38 concerns in the mapping are currently written this way.");
    }
}
