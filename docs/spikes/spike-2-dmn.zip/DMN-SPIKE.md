# Spike 2 — the decision engine

Drop these files into the existing `spike` project and re-run `mvn test`.
You should go from 3 tests to 9.

```bash
cd ~/Downloads/spike          # wherever you unzipped it
unzip -o ~/Downloads/botin-dmn-spike.zip
mvn test
```

## What it proves

Not a go/no-go gate — spikes 1 and 3 were the ones that could kill the design.
This one turns two claims from the design into something you can see fail.

**1. Row order is logic, not formatting.** Three `.dmn` files sit in
`src/main/resources/dmn/`. `spike-decision` and `spike-decision-misordered`
contain *exactly the same four rules* — the only difference is that the catch-all
moved from last to first. Same facts in, and one says `auto_waive` while the other
says `route_agent_catchall`. In the real system that is the difference between a
partner being paid and not being paid.

**2. A table with no catch-all returns nothing.** `spike-decision-nocatchall` is
the same table minus its last row. Feed it a case nothing matches and the engine
returns `null` — not a default, not an error. In a real process the gateway reading
`${tier}` then has no branch to take. **Thirteen of the 38 concerns in the mapping
are currently written without a catch-all.**

**3. The DMN engine is already on the classpath.** Nothing was added to `pom.xml`.
`flowable-spring-boot-starter` ships the process engine and the decision engine
together — that is why ADR-002 costs no new library. If this test runs at all,
that claim is confirmed.

## Things worth noticing in the files

- **Inputs are read by name.** `<inputExpression><text>category</text></inputExpression>`
  reads a process variable called `category`. That single line is the entire join
  between the process engine and the decision engine.
- **An empty `<text></text>` means "don't care"** — the `-` you see in a modeller.
- **Cells are expressions, not values.** `&gt;= 0.7`, `&lt;= 2`, `"health_issue"`.
  Change `>= 0.7` to `>= 0.8`, redeploy the file, and behaviour changes with no Java
  recompiled. That is the benefit in ADR-002 and the hazard in D-3, in one edit.

## If it fails

The DMN API is the least-verified part of what I wrote — I could not build against
Flowable in my sandbox. The two most likely problems:

- `DmnDecisionService` not found → in older Flowable it was `DmnRuleService`.
- The `.dmn` files not deployed → Flowable's Spring Boot autoconfiguration scans
  `classpath*:/dmn/`. Confirm the files landed in `src/main/resources/dmn/`.

Send me the error either way.
